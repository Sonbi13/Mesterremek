<?php
    require_once('db_connect.php');

    
    function jarmu_lekerdezes(){
        $mysqli = db_connect();
        $sql = "SELECT autok.id, autok.gyarto, autok.tipus, autok.uzemanyag, autok.kategoria_id, autok.futott_km, autok.netto_ar, autok.eladva, autok.leiras, auto_kategoriak.id, auto_kategoriak.nev FROM autok INNER JOIN auto_kategoriak ON autok.kategoria_id = auto_kategoriak.id";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $jarmuvek[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $jarmuvek;
    }
?>