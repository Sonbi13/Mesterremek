<?php
    require_once('db_connect.php');

    function jarmu_felvitel(){
        $mysqli = db_connect();
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $uzemanyag = $_POST['uzemanyag'];
        $futott_km = $_POST['futott_km'];
        $netto_ar = $_POST['netto_ar'];
        $leiras = $_POST['leiras'];
        $kategoria_id = $_POST['kategoria_id'];
        if (isset($_POST['eladva'])){
            $eladva = 1;
        } else {
            $eladva = 0;
        }
        $sql = "INSERT INTO autok (gyarto,tipus,uzemanyag, futott_km, netto_ar, leiras, eladva, kategoria_id) VALUES ('$gyarto','$tipus','$uzemanyag','$futott_km','$netto_ar', '$leiras', '$eladva', '$kategoria_id')";
        $eredmeny = $mysqli->query($sql);
    
        
        if ($eredmeny) {
            
            $url = './index.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>