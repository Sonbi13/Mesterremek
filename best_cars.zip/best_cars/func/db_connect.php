<?php
    header('Content-Type: text/html; charset=utf-8');

    
    function db_connect(){
        
        $mysqli = new mysqli("localhost","root", "", "best_cars");
        if (!$mysqli){
            die("Nem lehet csatlakozni az adatbázishoz!!!".$mysqli->error);
        }
    return $mysqli;
    }
?>