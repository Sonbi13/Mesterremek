<?php
    require_once('db_connect.php');

    function jarmu_kerdez_id($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `autok` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $jarmu = mysqli_fetch_assoc($eredmeny);
        return $jarmu;
    }

    function jarmu_modosit(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $uzemanyag = $_POST['uzemanyag'];
        $futott_km = $_POST['futott_km'];
        $netto_ar = $_POST['netto_ar'];
        $leiras = $_POST['leiras'];
       
        
        $kategoria_id = $_POST['kategoria_id'];
        if (isset($_POST['eladva'])){
            $eladva = 1;
        } else {
            $eladva = 0;
        }

        $sql = "UPDATE `autok` SET `gyarto` = '$gyarto',
        `tipus` = '$tipus',`uzemanyag` = '$uzemanyag',`futott_km` = '$futott_km', 
        `netto_ar` = '$netto_ar',`leiras` = '$leiras', 'kategoria_id' = '$kategoria_id',
        `eladva` = '$eladva' WHERE `id`='$id'";

        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "index.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>