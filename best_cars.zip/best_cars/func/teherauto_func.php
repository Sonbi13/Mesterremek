<?php
    require_once('db_connect.php');

   
    function kamion_lekerdez(){
        $mysqli = db_connect();
        if ('kategoria_id' == '2'){
           
        $sql = "SELECT autok.id, autok.gyarto, autok.tipus, autok.uzemanyag, autok.kategoria_id, autok.futott_km, autok.netto_ar, autok.eladva, autok.leiras
        autok_kategoriak.nev FROM autok INNER JOIN auto_kategoriak ON autok.kategoria_id = auto_kategoriak.id";
    $eredmeny = $mysqli->query($sql);
    if ($eredmeny){
        while ($sor = mysqli_fetch_assoc($eredmeny)){
            $csapatok[] = $sor;
        }
    } else {
        die("SQL hiba: ".$mysqli->error);
    }
    mysqli_close($mysqli);
return $csapatok;
}
        }

?>