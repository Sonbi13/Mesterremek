<?php
    require_once('header.php');
    require_once('functions/func_szures_listaz.php');
    $trucks = kamion_lekerdez();
    
   
   
?>
<div class="container mt-3">
    <table class="table table-hover">
        <thead>
        <th>ID</th>
            <th>Gyártó</th>
            <th>Típus</th>
            <th>Üzemanyag</th>
            <th>Kategória</th>
            <th>Futott km</th>
            <th>Bruttó ár</th>
            <th>Eladva</th>
            <th>Leírás</th>
            
        </thead>
        <tbody>
             <?php
             foreach ($trucks as $trucks){
                 if ($trucks['kategoria_id']==2) {
                    echo "<tr>";
                    echo "<td>". $trucks['id']. "</td>";
                    echo "<td>". $trucks['gyarto']. "</td>";
                    echo "<td>". $trucks['tipus']. "</td>";
                    echo "<td>". $trucks['uzemanyag']. "</td>";
                    echo "<td>". $trucks['kategoria_id']. "</td>";
                    echo "<td>". $trucks['futott_km']. "</td>";
                    echo "<td>". $trucks['netto_ar']. "</td>";
                    echo "<td>";
                    $trucks['eladva'] ? print "igen" : print "nem";
                echo "</td>";
                   
                    echo "<td>";
                        echo '<a class="btn btn-warning" href="modositas.php?id='. $trucks['id'].'"> Módosít </a> ';
                        echo '<a class="btn btn-danger" href="torles.php?id='. $trucks['id'].'"> Töröl </a>';
                    echo "</td>";
                echo "</tr>";
                     # code...
                 }

             }
             ?>
        </tbody>   
    </table>
    <a class="btn btn-primary" href="listazas.php">Vissza</a>   

</div>
</body>
</html>
