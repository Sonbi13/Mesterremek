<?php
    require_once('header.php');
    require_once('func/func_listazas.php');
    $jarmuvek = jarmu_lekerdezes();
    
   
   
?>
<div class="container mt-3">
    <table class="table table-hover">
        <thead>
            <th>ID</th>
            <th>Gyártó</th>
            <th>Típus</th>
            <th>Üzemanyag</th>
            <th>Kategória</th>
            <th>Futott km</th>
            <th>Bruttó ár</th>
            <th>Eladva</th>
            <th>Leírás</th>
            
        </thead>
        <tbody>
             <?php
             foreach ($jarmuvek as $jarmu){
                echo "<tr>";
                    echo "<td>". $jarmu['id']. "</td>";
                    echo "<td>". $jarmu['gyarto']. "</td>";
                    echo "<td>". $jarmu['tipus']. "</td>";
                    echo "<td>". $jarmu['uzemanyag']. "</td>";
                    echo "<td>". $jarmu['kategoria_id']. "</td>";
                    echo "<td>". $jarmu['futott_km']. "</td>";
                    echo "<td>". $jarmu['netto_ar']."</td>";
                    echo "<td>". $jarmu['eladva']."</td>";
                    echo "<td>". $jarmu['leiras']."</td>";
                    
                    echo "<td>";
                       
                    echo "<td>";
                        echo '<a class="btn btn-warning" href="modositas.php?id='. $jarmu['id'].'"> Módosít </a> ';
                        echo '<a class="btn btn-danger" href="torles.php?id='. $jarmu['id'].'"> Töröl </a>';
                    echo "</td>";
                echo "</tr>";
             }
             ?>
        </tbody>   
    </table>
    <a class="btn btn-primary" href="uj_jarmu.php">Új jármű feltöltés</a>         
</div>
</body>
</html>