<?php
    require_once('header.php');
    require_once('func/func_modositas.php');
    require_once('func/func_kategoriak.php');
 
   
    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    $jarmu_kategoriak = jarmu_kat();

    $jarmu = jarmu_kerdez_id($id);

    
    if (isset($_POST['modosit'])){
        jarmu_modosit(); 
    }

?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="uzemanyag">Gyártó</label>
                        <input type="text" class="form-control" name="uzemanyag" id="uzemanyag" value="<?php echo $jarmu['uzemanyag']; ?>" placeholder="Gyártó" required>
                    </div> 
                    <div class="form-group">
                        <label for="uzemanyag">Típus</label>
                        <input type="text" class="form-control" value="<?php echo $jarmu['uzemanyag']; ?>" name="uzemanyag" id="uzemanyag" placeholder="Típus" required>
                    </div> 
                    <div class="form-group">
                        <label for="uzemanyag">Üzemanyag</label>
                        <input type="text" class="form-control" name="uzemanyag" id="uzemanyag" value="<?php echo $jarmu['uzemanyag']; ?>" placeholder="Üzemanyag" required>
                    </div> 
                    <div class="form-group">
                        <label for="kategoria_id">Kategóriák</label>
                        <select name="kategoria_id" id="kategoria_id" class="form-select">
                            <?php
                            $selected = ""; 
                            foreach ($jarmu_kategoriak as $jarmu_kategoria) {
                                
                                $jarmu_kategoria['id'] == $jarmu['kategoria_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$jarmu_kategoria['id']." $selected>".$jarmu_kategoria['megnevezes']."</option>";
                            }
                            ?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="futott_km">Futott km</label>
                        <input type="number" class="form-control" name="futott_km" id="futott_km" value="<?php echo $jarmu['futott_km']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="netto_ar">Bruttó ár</label>
                        <input type="number" value="<?php echo $jarmu['netto_ar']; ?>"class="form-control" name="netto_ar" id="netto_ar" required>
                    </div>
                  
                    <div class="form-group">
                        <label for="leiras">Leírás</label>
                        <input class="form-control" name="leiras" id="leiras" type="text">
                        
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="eladva" id="eladva" <?php $jarmu['eladva'] == 1 ? print "checked" : print "";?>>
                        <label class="form-check-label" for="eladva">
                           Eladva
                        </label>
                    </div>
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="modosit" value="MÓDOSÍT" class="btn btn-success mt-3">
            </div> 
            </form>
        </div> 
    </div> 
</div>
</body>
</html>