<?php
require_once("db_connect.php");


function etel_feltoltes()
{
    $mysqli = db_connect();
    $megnevezes = $_POST['megnevezes'];
    $netto_ar = $_POST['netto_ar'];
    $afa = $_POST['afa'];
    $kategoria_id = $_POST['kategoria_id'];
    if(isset($_POST['akcios']))
    {
        $akcios = 1;
    }else
    {
        $akcios = 0;
    }
   
    $sql = "INSERT INTO etelek (megnevezes, netto_ar, afa, kategoria_id, akcios) VALUES ('$megnevezes', '$netto_ar', '$afa', '$kategoria_id', '$akcios')";
    $eredmeny = $mysqli->query($sql);

    mysqli_close($mysqli);
}

