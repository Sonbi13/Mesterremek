<?php
    require_once('db_connect.php');

    function kategoria_lekerdez()
	{
        $mysqli = db_connect();
        $sql = "SELECT * FROM etel_kategoriak";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny)
		{
			$kategoriak = [];
            while ($sor = $eredmeny->fetch_assoc())
			{
                $kategoriak[] = $sor;
            }
        } 
		else 
		{
			$kategoriak = false;
            die("SQL hiba: ".$mysqli->error);
        }
        $mysqli->close();
    return $kategoriak;
    }
?>
