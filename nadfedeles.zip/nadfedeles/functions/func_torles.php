<?php

require_once("db_connect.php");

function etel_torles()
{
    $mysqli = db_connect();
    $id = $_POST['id'];
    $sql = "DELETE FROM etelek WHERE id = $id";
    $eredmenyek = $mysqli->query($sql);

    if($eredmenyek)
    {
        $url = 'etel_listaz.php';
        header("Location: ". $url);
    }

}