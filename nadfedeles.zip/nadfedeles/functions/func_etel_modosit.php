<?php
require_once("db_connect.php");



function etel_modositas()
{
    $mysqli = db_connect();
    $id = $_POST['id'];
    $megnevezes = $_POST['megnevezes'];
    $netto_ar = $_POST['netto_ar'];
    $afa = $_POST['afa'];
    $kategoria_id = $_POST['kategoria_id'];
    $akcios = $_POST['akcios'];
    $sql = "UPDATE etelek SET megnevezes = '$megnevezes', netto_ar = '$netto_ar', afa = '$afa', kategoria_id = '$kategoria_id', akcios = '$akcios' WHERE id = '$id'";
    $eredmeny = $mysqli->query($sql);

    if($eredmeny)
    {
        $url = 'etel_listaz.php';
        header("Location: ". $url);
    }

    mysqli_close($mysqli);
}