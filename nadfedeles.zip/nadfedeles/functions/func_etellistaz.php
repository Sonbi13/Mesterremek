<?php
    require_once('db_connect.php');

    function etel_lekerdez()
	{
        $mysqli = db_connect();
        $sql = "SELECT etelek.id, etelek.megnevezes, etelek.netto_ar, etelek.kategoria_id, etelek.akcios, etel_kategoriak.nev FROM etelek INNER JOIN etel_kategoriak ON etelek.kategoria_id = etel_kategoriak.id ORDER BY etelek.id DESC";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny)
		{
			$adatok = [];
            while ($sor = $eredmeny->fetch_assoc())
			{
                $adatok[] = $sor;
            }
        } 
		else 
		{
			$adatok = false;
            die("SQL hiba: ".$mysqli->error);
        }
        $mysqli->close();
    return $adatok;
    }
?>
