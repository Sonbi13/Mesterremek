<?php
require_once("header.php");
require_once("menu.php");
require_once("functions/func_etel_modosit.php");
require_once("functions/func_kategoria.php");


$kategoria = kategoria_lekerdez();


if(isset($_POST['modosit']))
{
    etel_modositas();
}

?>

<div class = "container mt-3">
    <div class = "row">
        <div class = "col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method = "POST">
            <div class = "col-sm-6">

                    <div class = "form-group">
                        <label for="megnevezes">Megnevezés</label>
                        <input type="text" name = "megnevezes" id = "megnevezes"  required>
                    </div>
                    <div class = "form-group">
                        <label for="netto_ar">Nettó ár</label>
                        <input type="number" name = "netto_ar" id = "netto_ar"  required>
                    </div>
                    <div class = "form-group">
                        <select name="afa" id="afa">
                            <option value="0">0%</option>
                            <option value="15">15%</option>
                            <option value="27" selected>27%</option>
                        </select>
                    </div>
                    <div class = "form-group">
                        <label for="kategoria_id">Kategóriák</label>
                        <select name="kategoria_id" id="kategoria_id" class = "form-select">
                            <?php
                            foreach($kategoria as $kategoriak)
                            {
                                echo "<option value = ".$kategoriak['id'].">".$kategoriak['nev']."</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class = "form-group">
                        <label for="akcios">Akciós-e az étel?</label>
                        <input type="checkbox" name = "akcios" id = "akcios">
                    </div>

                    <input type="submit" name = "modosit" id = "modosit" Value = "Módosítás" class = "btn btn-primary">
                    <a href = "javascript:history.back()" class = "btn btn-warning">Mégsem</a>

            </div>
        </form>
        </div>
    </div>
</div>