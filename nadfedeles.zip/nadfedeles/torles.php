<?php
require_once("header.php");
require_once("menu.php");
require_once("functions/func_torles.php");

if(isset($_GET['id']))
{
    $id = $_GET['id'];
}

if(isset($_POST['torol']))
{
    etel_torles();
}
?>

<div class = "container mt-3">
    <div class = "row">
        <div class = "col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method = "POST">
            <div class = "col-sm-6">
                    <div class = "form-group">

                            <input type="hidden" name = "id" value = "<?php echo $id; ?>">
                            <P>Tényleg törli: <?php echo $id;?></p>
                            <input type="submit" name = "torol" id = "torol" value = "Törlés" class = "btn btn-danger">
                            <a href = "javascript:history.back()" class = "btn btn-warning">Mégse</a>

                    </div>
            </div>
        </form>
        </div>
    </div>
</div>

