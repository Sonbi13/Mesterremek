<?php
require_once("menu.php");
require_once("header.php");
require_once("functions/func_feltolt.php");
require_once("functions/func_kategoria.php");

$etel_kat = kategoria_lekerdez();

if(isset($_POST['feltolt']))
{
    etel_feltoltes();
}

?>

<div class = "container mt-3">
    <div class = "row">
        <div class = "col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF'];?>" method = "POST">
            <div class = "col-sm-6">

                    <div class = "form-group">
                            <label for = "megnevezes">Megnevezés</label>
                            <input type="text" name = "megnevezes" id = "megnevezes" required>

                    </div>
                    <div class = "form-group">
                            <label for = "netto_ar">Nettó ár</label>
                            <input type="number" name = "netto_ar" id = "netto_ar" required>

                    </div>
                    <div class = "form-group">
                            <label for = "afa">ÁFA</label>
                            <select name="afa" id="afa">
                                <option value="0">0%</option>
                                <option value="15">15%</option>
                                <option value="27" selected>27%</option>
                            </select>

                    </div>
                    <div class = "form-group">
                            <label for = "kategoria_id">Kategóriák</label>
                            <select name="kategoria_id" id="kategoria_id" class = "form-select">
                            <?php 
                            foreach ($etel_kat as $etel_katok) {
                                echo "<option value=".$etel_katok['id'].">".$etel_katok['nev']."</option>";
                            }
                            ?>
                            </select>

                    </div>
                    <div class = "form-group">
                        <Label for = "akcios">Ha az étel akciós pipálja be</Label>
                        <input type="checkbox" id ="akcios" name = "akcios" value = '1'>
                    </div>

                    <input type="submit" name = "feltolt" id = "feltolt" Value = "Feltöltés" class = "btn btn-primary">

            </div>
            </form>
        </div>
    </div>
</div>