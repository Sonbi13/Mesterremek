<?php
require_once("menu.php");
require_once("header.php");
require_once('functions/func_akcios_etel.php');
require_once('functions/func_kategoria.php');

$kategoria = kategoria_lekerdez();
$etel = akcios_lekerdez();

if(isset($_POST['szures']))
{

}


?>

<div class="container mt-3">
    <table class="table table-hover">
        <thead>
            <th>Megnevezés</th>
            <th>Bruttó ár</th>
            <th>Kategóriák</th>
            <th>Akciós?</th>
            
        </thead>
        <tbody>
             <?php
             foreach ($etel as $etelek)
			 {
                echo "<tr>";
                    echo "<td>". $etelek['megnevezes']. "</td>";
                    echo "<td>". $etelek['netto_ar'] * 1.27. "</td>";
                    echo "<td>". $etelek['nev']. "</td>";
                    echo "<td>";
                    $etelek['akcios'] ? print "IGEN" : print "NEM";
                    
                    echo "</tr>";
             }
             ?>
        </tbody>   
    </table>