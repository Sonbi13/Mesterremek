<?php
    require_once('header.php');
    require_once('functions/func_etellistaz.php');
    require_once('functions/func_kategoria.php');

    $kategoria = kategoria_lekerdez();
    $etel = etel_lekerdez();

    if(isset($_POST['szures']))
    {

    }
   
    
?>
<div class="container mt-3">
    <table class="table table-hover">
        <h1  text align = "center">Schönberger Dominik - 14.I</h1>
        <br>
        <a class = "btn btn-primary" href = "feltolt.php">Étel feltöltés</a>
        <thead>
            <th>Megnevezés</th>
            <th>Bruttó ár</th>
            <th>Kategóriák</th>
            <th>Akciós?</th>
            <th>Műveletek</th>
        </thead>
        <tbody>
             <?php
             foreach ($etel as $etelek)
			 {
                echo "<tr>";
                    echo "<td>". $etelek['megnevezes']. "</td>";
                    echo "<td>". $etelek['netto_ar'] * 1.27. "</td>";
                    echo "<td>". $etelek['nev']. "</td>";
                    echo "<td>";
                    $etelek['akcios'] ? print "IGEN" : print "NEM";
                    
                    echo "<td>";
                    echo '<a href = "modositas.php?id = '.$etelek['id'].'" class = "btn btn-primary">Módosítás</a> ';
                    echo '<a href = "torles.php?id = '.$etelek['id'].'" class = "btn btn-danger">Törlés</a> ';
                    echo "<td>";
                     
                echo "</tr>";
             }
             ?>
        </tbody>   
    </table>
                <select name="kategoria_id" id="kategoria_id">
                    <?php
                    foreach($kategoria as $kategoriak)
                    echo "<option value = ".$kategoriak['id'].">".$kategoriak['nev']."</option>";
                    ?>
                </select>
                <input type="submit" class = "btn btn-warning" value = "Szűrés" name = "szures">
                <a class = "btn btn-warning" href = "akcios_etelek.php">Akciós ételek szűrése</a>
</div>
</body>
</html>


