﻿using System;
using System.IO;
using MySql.Data.MySqlClient;



namespace adatbazis
{
    internal class Program
    {
        static void Main()
        {
            adatbazisletrehozas();
            fajlathelyezes();
            adatbazis();
           
            //elérsi út mindennél
            //táblák neve
            //táblák mezői


            Console.ReadKey();
        }
        static void adatbazisletrehozas()
        {
            string kacspolat = "Server=127.0.0.1;Uid=root;Pwd= ;charset=utf8;port=3306;";

            try
            {
                using (MySqlConnection kapcs = new MySqlConnection(kacspolat))
                {
                    kapcs.Open();
                    Console.WriteLine("OK");

                    string dbs = "CREATE DATABASE IF NOT EXISTS hajok_kt DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";

                    using (MySqlCommand command = new MySqlCommand(dbs, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("OK");
                    }
                }
            }
            catch (MySqlException)
            {
                
                    using (MySqlConnection kapcs = new MySqlConnection("Server=127.0.0.1;Uid=root;Pwd= ;charset=utf8;port=3306;"))
                    {
                        kapcs.Open();
                        Console.WriteLine("OK");

                        string dbs = "CREATE DATABASE IF NOT EXISTS hajok_kt DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";

                        using (MySqlCommand command = new MySqlCommand(dbs, kapcs))
                        {
                            command.ExecuteNonQuery();
                            Console.WriteLine("OK");
                        }
                    }
                
               
            }


        }
        static void fajlathelyezes()
        {
            string hajok = "hajo.txt";
            string allapot = "allapot.txt";
            string varos = "varos.txt";
            string cel = @"C:\xampp\mysql\data\hajok_kt"; 


            FileInfo nev = new FileInfo(hajok);
            string eleres = Path.Combine(cel, nev.Name);
            nev.CopyTo(eleres, true);


            FileInfo nev1 = new FileInfo(allapot);
            string eleres1 = Path.Combine(cel, nev1.Name);
            nev1.CopyTo(eleres1, true);


            FileInfo nev2 = new FileInfo(varos);
            string eleres2 = Path.Combine(cel, nev2.Name);
            nev2.CopyTo(eleres2, true);
        }
        static void adatbazis()
        {


            string kacspolat = "Server=127.0.0.1;Database=hajok_kt;Uid=root;Pwd= ;charset=utf8;port=3306;";


            try
            {
                using (MySqlConnection kapcs = new MySqlConnection(kacspolat))
                {
                    kapcs.Open();
                    Console.WriteLine("OK");

                    string tablak = "DROP TABLE IF EXISTS `allapot`;\r\nCREATE TABLE IF NOT EXISTS `allapot` (\r\n  `az` int NOT NULL,\r\n  `uzemel` int DEFAULT NULL,\r\n  `hol` varchar(22) DEFAULT NULL,\r\n  PRIMARY KEY (`az`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;" + "DROP TABLE IF EXISTS `hajo`;\r\nCREATE TABLE IF NOT EXISTS `hajo` (\r\n  `az` int NOT NULL,\r\n  `nev` varchar(26) DEFAULT NULL,\r\n  `hossz` decimal(4,1) DEFAULT NULL,\r\n  `szelesseg` decimal(4,2) DEFAULT NULL,\r\n  `merules` varchar(3) DEFAULT NULL,\r\n  `mszam` varchar(1) DEFAULT NULL,\r\n  `mteljesitmeny` varchar(4) DEFAULT NULL,\r\n  `utas` int DEFAULT NULL,\r\n  `epult` int DEFAULT NULL,\r\n  `orszag` varchar(2) DEFAULT NULL,\r\n  `regvar` int DEFAULT NULL,\r\n  `regor` varchar(2) DEFAULT NULL,\r\n  `allapotaz` int DEFAULT NULL,\r\n  PRIMARY KEY (`az`),\r\n  KEY `varos_hajo` (`regvar`),\r\n  KEY `allapot_hajo` (`allapotaz`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;" + "DROP TABLE IF EXISTS `varos`;\r\nCREATE TABLE IF NOT EXISTS `varos` (\r\n  `az` int NOT NULL,\r\n  `nev` varchar(13) DEFAULT NULL,\r\n  PRIMARY KEY (`az`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;";
                    using (MySqlCommand command = new MySqlCommand(tablak, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("OK");
                    }
                    string import1 = "LOAD DATA INFILE 'hajo.txt' INTO TABLE hajo;";
                    using (MySqlCommand command = new MySqlCommand(import1, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla1");
                    }
                    string import2 = "LOAD DATA INFILE 'allapot.txt' INTO TABLE allapot;";
                    using (MySqlCommand command = new MySqlCommand(import2, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla2");
                    }
                    string import3 = "LOAD DATA INFILE 'varos.txt' INTO TABLE varos;";
                    using (MySqlCommand command = new MySqlCommand(import3, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla3");
                    }
                }
               
            }
            catch (MySqlException)
            {
                using (MySqlConnection kapcs = new MySqlConnection("Server=127.0.0.1;Database=hajok_kt;Uid=root;Pwd= ;charset=utf8;port=3306;"))
                {
                    kapcs.Open();
                    Console.WriteLine("OK");

                 
                    string dbs = "CREATE DATABASE IF NOT EXISTS hajok_kt DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;";

                    using (MySqlCommand command = new MySqlCommand(dbs, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("OK");
                    }
                    string tablak = "DROP TABLE IF EXISTS `allapot`;\r\nCREATE TABLE IF NOT EXISTS `allapot` (\r\n  `az` int NOT NULL,\r\n  `uzemel` int DEFAULT NULL,\r\n  `hol` varchar(22) DEFAULT NULL,\r\n  PRIMARY KEY (`az`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;" + "DROP TABLE IF EXISTS `hajo`;\r\nCREATE TABLE IF NOT EXISTS `hajo` (\r\n  `az` int NOT NULL,\r\n  `nev` varchar(26) DEFAULT NULL,\r\n  `hossz` decimal(4,1) DEFAULT NULL,\r\n  `szelesseg` decimal(4,2) DEFAULT NULL,\r\n  `merules` varchar(3) DEFAULT NULL,\r\n  `mszam` varchar(1) DEFAULT NULL,\r\n  `mteljesitmeny` varchar(4) DEFAULT NULL,\r\n  `utas` int DEFAULT NULL,\r\n  `epult` int DEFAULT NULL,\r\n  `orszag` varchar(2) DEFAULT NULL,\r\n  `regvar` int DEFAULT NULL,\r\n  `regor` varchar(2) DEFAULT NULL,\r\n  `allapotaz` int DEFAULT NULL,\r\n  PRIMARY KEY (`az`),\r\n  KEY `varos_hajo` (`regvar`),\r\n  KEY `allapot_hajo` (`allapotaz`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;" + "DROP TABLE IF EXISTS `varos`;\r\nCREATE TABLE IF NOT EXISTS `varos` (\r\n  `az` int NOT NULL,\r\n  `nev` varchar(13) DEFAULT NULL,\r\n  PRIMARY KEY (`az`)\r\n) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;";
                    using (MySqlCommand command = new MySqlCommand(tablak, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("OK");
                    }
                    string import1 = "LOAD DATA INFILE 'hajo.txt' INTO TABLE hajo;";
                    using (MySqlCommand command = new MySqlCommand(import1, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla1");
                    }
                    string import2 = "LOAD DATA INFILE 'allapot.txt' INTO TABLE allapot;";
                    using (MySqlCommand command = new MySqlCommand(import2, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla2");
                    }
                    string import3 = "LOAD DATA INFILE 'varos.txt' INTO TABLE varos;";
                    using (MySqlCommand command = new MySqlCommand(import3, kapcs))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine("Tabla3");
                    }
                }

            }



        }
       



    }
       
        
    
}
