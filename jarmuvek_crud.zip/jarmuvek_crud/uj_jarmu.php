<?php
    require_once('header.php');
    require_once('func/func_feltoltes.php');
    require_once('func/func_kategoriak.php');
 
    $jarmu_kategoriak = jarmu_kat();
    
    if (isset($_POST['ment'])){
        jarmu_felvitel(); 
    }

?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="rendszam">Rendszám</label>
                        <input type="text" class="form-control" name="rendszam" id="rendszam" placeholder="Rendszám" required>
                    </div> 
                    <div class="form-group">
                        <label for="gyarto">Gyártó</label>
                        <input type="text" class="form-control" name="gyarto" id="gyarto" placeholder="Gyártó" required>
                    </div> 
                    <div class="form-group">
                        <label for="tipus">Típus</label>
                        <input type="text" class="form-control" name="tipus" id="tipus" placeholder="Típus" required>
                    </div> 
                    <div class="form-group">
                        <label for="kategoria_id">Kategóriák</label>
                        <select name="kategoria_id" id="kategoria_id" class="form-select">
                            <?php 
                            foreach ($jarmu_kategoriak as $jarmu_kategoria) {
                                echo "<option value=".$jarmu_kategoria['id'].">".$jarmu_kategoria['megnevezes']."</option>";
                            }
                            ?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="motorterfogat">Motortérfogat</label>
                        <input type="number" class="form-control" name="motorterfogat" id="motorterfogat" required>
                    </div>
                    <div class="form-group">
                        <label for="szallithato_szemelyek_szama">Férő helyek</label>
                        <input type="number" class="form-control" name="szallithato_szemelyek_szama" id="szallithato_szemelyek_szama" required>
                    </div>
                    <div class="form-group">
                        <label for="gyartasi_ev">Gyártási év</label>
                        <input class="form-control" name="gyartasi_ev" id="gyartasi_ev" type="number" required>
                    </div>
                    <div class="form-group">
                        <label for="rogzites_ideje">Rögzítés</label>
                        <input class="form-control" name="rogzites_ideje" id="rogzites_ideje" type="number" required>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="allapot" id="allapot" >
                        <label class="form-check-label" for="allapot">
                           Állapot
                        </label>
                    </div>
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="ment" value="MENTÉS" class="btn btn-success mt-3">
            </div> 
            </form>
        </div> 
    </div> 
</div>
</body>
</html>