<?php
    require_once('header.php');
    require_once('func/func_listazas.php');
    $jarmuvek = jarmu_lekerdezes();
    
   
   
?>
<div class="container mt-3">
    <table class="table table-hover">
        <thead>
            <th>ID</th>
            <th>Rendszám</th>
            <th>GYártó</th>
            <th>Típus</th>
            <th>Motortérfogat</th>
            <th>Ülő hely</th>
            <th>Gyártási év</th>
            <th>Rögzítés ideje</th>
            <th>Állapot</th>
            <th>Kategória</th>
        </thead>
        <tbody>
             <?php
             foreach ($jarmuvek as $jarmu){
                echo "<tr>";
                    echo "<td>". $jarmu['id']. "</td>";
                    echo "<td>". $jarmu['rendszam']. "</td>";
                    echo "<td>". $jarmu['gyarto']. "</td>";
                    echo "<td>". $jarmu['tipus']. "</td>";
                    echo "<td>". $jarmu['motorterfogat']. "</td>";
                    echo "<td>". $jarmu['szallithato_szemelyek_szama']. "</td>";
                    echo "<td>". $jarmu['gyartasi_ev']."</td>";
                    echo "<td>". $jarmu['rogzites_ideje']."</td>";
                    echo "<td>". $jarmu['allapot']."</td>";
                    echo "<td>". $jarmu['kategoria_id']."</td>";
                    echo "<td>";
                       
                    echo "<td>";
                        echo '<a class="btn btn-warning" href="modositas.php?id='. $jarmu['id'].'"> Módosít </a> ';
                        echo '<a class="btn btn-danger" href="torles.php?id='. $jarmu['id'].'"> Töröl </a>';
                    echo "</td>";
                echo "</tr>";
             }
             ?>
        </tbody>   
    </table>
    <a class="btn btn-primary" href="uj_jarmu.php">Új jármű feltöltés</a>         
</div>
</body>
</html>