<?php
    require_once('db_connect.php');

    
    function jarmu_lekerdezes(){
        $mysqli = db_connect();
        $sql = "SELECT jarmuvek.id, jarmuvek.rendszam, jarmuvek.gyarto, jarmuvek.tipus, jarmuvek.motorterfogat, jarmuvek.szallithato_szemelyek_szama, jarmuvek.gyartasi_ev, jarmuvek.rogzites_ideje, jarmuvek.allapot, jarmuvek.kategoria_id, jarmu_kategoriak.megnevezes, jarmu_kategoriak.allapot FROM jarmuvek INNER JOIN jarmu_kategoriak ON jarmuvek.kategoria_id = jarmu_kategoriak.id";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $jarmuvek[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $jarmuvek;
    }
?>