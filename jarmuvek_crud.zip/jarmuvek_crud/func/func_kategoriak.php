<?php
    require_once('db_connect.php');

    
    function jarmu_kat(){
        $mysqli = db_connect();
        $sql = "SELECT * FROM jarmu_kategoriak";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $jarmu_kategoriak[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $jarmu_kategoriak;
    }
?>