<?php
    require_once('db_connect.php');

    function jarmu_kerdez_id($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `jarmuvek` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $jarmu = mysqli_fetch_assoc($eredmeny);
        return $jarmu;
    }

    function jarmu_modosit(){
        $mysqli = db_connect();
        $id = $_POST['id'];
        $rendszam = $_POST['rendszam'];
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $motorterfogat = $_POST['motorterfogat'];
        $szallithato_szemelyek_szama = $_POST['szallithato_szemelyek_szama'];
        $gyartasi_ev = $_POST['gyartasi_ev'];
        $rogzites_ideje = $_POST['rogzites_ideje'];
        
        $kategoria_id = $_POST['kategoria_id'];
        if (isset($_POST['allapot'])){
            $allapot = 1;
        } else {
            $allapot = 0;
        }

        $sql = "UPDATE `jarmuvek` SET `rendszam` = '$rendszam',
        `gyarto` = '$gyarto',`tipus` = '$tipus',`motorterfogat` = '$motorterfogat', 
        `szallithato_szemelyek_szama` = '$szallithato_szemelyek_szama',`gyartasi_ev` = '$gyartasi_ev',`rogzites_ideje` = '$rogzites_ideje', 'kategoria_id' = '$kategoria_id',
        `allapot` = '$allapot' WHERE `id`='$id'";

        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "index.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>