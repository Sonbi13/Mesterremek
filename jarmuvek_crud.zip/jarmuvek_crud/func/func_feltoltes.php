<?php
    require_once('db_connect.php');

    function jarmu_felvitel(){
        $mysqli = db_connect();
        $rendszam = $_POST['rendszam'];
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $motorterfogat = $_POST['motorterfogat'];
        $szallithato_szemelyek_szama = $_POST['szallithato_szemelyek_szama'];
        $gyartasi_ev = $_POST['gyartasi_ev'];
        $rogzites_ideje = $_POST['rogzites_ideje'];
        $kategoria_id = $_POST['kategoria_id'];
        if (isset($_POST['allapot'])){
            $allapot = 1;
        } else {
            $allapot = 0;
        }
        $sql = "INSERT INTO jarmuvek (rendszam,gyarto,tipus,motorterfogat,szallithato_szemelyek_szama, gyartasi_ev, rogzites_ideje, allapot, kategoria_id) VALUES ('$rendszam','$gyarto','$tipus','$motorterfogat','$szallithato_szemelyek_szama','$gyartasi_ev','$rogzites_ideje','$allapot', '$kategoria_id')";
        $eredmeny = $mysqli->query($sql);
    
        
        if ($eredmeny) {
            
            $url = './index.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>