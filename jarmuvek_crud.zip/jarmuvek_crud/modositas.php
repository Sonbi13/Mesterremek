<?php
    require_once('header.php');
    require_once('func/func_modositas.php');
    require_once('func/func_kategoriak.php');
 
   
    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    $jarmu_kategoriak = jarmu_kat();

    $jarmu = jarmu_kerdez_id($id);

    
    if (isset($_POST['modosit'])){
        jarmu_modosit(); 
    }

?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="rendszam">Rendszám</label>
                        <input type="text" class="form-control" name="rendszam" id="rendszam" value="<?php echo $jarmu['rendszam']; ?>" placeholder="Gyártó" required>
                    </div> 
                    <div class="form-group">
                        <label for="gyarto">Gyártó</label>
                        <input type="text" class="form-control" value="<?php echo $jarmu['gyarto']; ?>" name="gyarto" id="gyarto" placeholder="Típus" required>
                    </div> 
                    <div class="form-group">
                        <label for="tipus">Típus</label>
                        <input type="text" class="form-control" name="tipus" id="tipus" value="<?php echo $jarmu['tipus']; ?>" placeholder="Üzemanyag" required>
                    </div> 
                    <div class="form-group">
                        <label for="kategoria_id">Kategóriák</label>
                        <select name="kategoria_id" id="kategoria_id" class="form-select">
                            <?php
                            $selected = ""; 
                            foreach ($jarmu_kategoriak as $jarmu_kategoria) {
                                
                                $jarmu_kategoria['id'] == $jarmu['kategoria_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$jarmu_kategoria['id']." $selected>".$jarmu_kategoria['megnevezes']."</option>";
                            }
                            ?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="motorterfogat">Motortérfogat</label>
                        <input type="number" class="form-control" name="motorterfogat" id="motorterfogat" value="<?php echo $jarmu['motorterfogat']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="szallithato_szemelyek_szama">Férő helyek</label>
                        <input type="number" value="<?php echo $jarmu['szallithato_szemelyek_szama']; ?>"class="form-control" name="szallithato_szemelyek_szama" id="szallithato_szemelyek_szama" required>
                    </div>
                    <div class="form-group">
                        <label for="gyartasi_ev">Gyártási év</label>
                        <input class="form-control" name="gyartasi_ev" id="gyartasi_ev" type="number">
                        
                    </div>
                    <div class="form-group">
                        <label for="rogzites_ideje">Rögzítés</label>
                        <input class="form-control" name="rogzites_ideje" id="rogzites_ideje" type="number">
                        
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="allapot" id="allapot" <?php $jarmu['allapot'] == 1 ? print "checked" : print "";?>>
                        <label class="form-check-label" for="allapot">
                           Állapot
                        </label>
                    </div>
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="modosit" value="MÓDOSÍT" class="btn btn-success mt-3">
            </div> 
            </form>
        </div> 
    </div> 
</div>
</body>
</html>