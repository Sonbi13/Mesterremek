-- jarmuvek DB létrehozása
CREATE SCHEMA `flotta` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci ;

use `flotta`;

-- jarmu_kategoriak tábla létrehozás
CREATE TABLE `flotta`.`jarmu_kategoriak` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `megnevezes` VARCHAR(45) NOT NULL,
  `allapot` TINYINT(1) NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `megnevezes_UNIQUE` (`megnevezes` ASC));

-- jarmuvek tábla létrehozás
CREATE TABLE `flotta`.`jarmuvek` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `rendszam` VARCHAR(20) NOT NULL,
  `gyarto` VARCHAR(150) NULL,
  `tipus` VARCHAR(150) NULL,
  `motorterfogat` INT NULL,
  `szallithato_szemelyek_szama` INT NULL,
  `gyartasi_ev` INT NULL,
  `rogzites_ideje` TIMESTAMP NULL,
  `allapot` TINYINT(1) NULL DEFAULT 1,
  `kategoria_id` INT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `rendszam_UNIQUE` (`rendszam` ASC));

-- néhány beszúrás a jarmű kategória táblába
INSERT INTO `flotta`.`jarmu_kategoriak` (`megnevezes`) VALUES ('személyautó');
INSERT INTO `flotta`.`jarmu_kategoriak` (`megnevezes`) VALUES ('tehergépjármű');
INSERT INTO `flotta`.`jarmu_kategoriak` (`megnevezes`, `allapot`) VALUES ('motorbicikli', '1');
INSERT INTO `flotta`.`jarmu_kategoriak` (`megnevezes`, `allapot`) VALUES ('roller', '0');
INSERT INTO `flotta`.`jarmu_kategoriak` (`megnevezes`, `allapot`) VALUES ('kerékpár', '1');

-- néhány beszúrás a járművek táblába
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('PCA-145', 'Opel', 'Corsa', '1300', '5', '1999', '1');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('PCR-120', 'Honda', 'Accord', '2000', '5', '2003', '1');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('NBB-245', 'Ford', 'Transit', '3000', '2', '2010', '2');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('MVV-741', 'Fiat', 'DFG', '2800', '3', '2015', '2');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('KDB-782', 'Trabant', '501', '500', '4', '1980', '1');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('HBF-123', 'Lada', '2109', '1300', '5', '1985', '1');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('LKF-741', 'Honda', 'R413', '500', '1', '2010', '3');
INSERT INTO `flotta`.`jarmuvek` (`rendszam`, `gyarto`, `tipus`, `motorterfogat`, `szallithato_szemelyek_szama`, `gyartasi_ev`, `kategoria_id`) VALUES ('RFA-175', 'Suzuki', 'W417', '1000', '1', '2018', '3');

-- idegenkulcs beállítások, FK 
-- hivatkozás épség megszorítás
ALTER TABLE `flotta`.`jarmuvek` 
ADD INDEX `jarmu_kat_FK_idx` (`kategoria_id` ASC);
;
ALTER TABLE `flotta`.`jarmuvek` 
ADD CONSTRAINT `jarmu_kat_FK`
  FOREIGN KEY (`kategoria_id`)
  REFERENCES `flotta`.`jarmu_kategoriak` (`id`)
  ON DELETE NO ACTION
  ON UPDATE NO ACTION;

DELETE FROM `flotta`.`jarmu_kategoriak` WHERE (`id` = '4');
DELETE FROM `flotta`.`jarmu_kategoriak` WHERE (`id` = '5');

-- idegenkulcs beállítások, FK 
-- update kaszkádolt: tovagyuruzo változtatás, az id mind a két helyen módosul
-- delete: null-ra állította a másik táblában
ALTER TABLE `flotta`.`jarmuvek` 
DROP FOREIGN KEY `jarmu_kat_FK`;
ALTER TABLE `flotta`.`jarmuvek` 
ADD CONSTRAINT `jarmu_kat_FK`
  FOREIGN KEY (`kategoria_id`)
  REFERENCES `flotta`.`jarmu_kategoriak` (`id`)
  ON DELETE SET NULL
  ON UPDATE CASCADE;

UPDATE `flotta`.`jarmu_kategoriak` SET `id` = '8' WHERE (`id` = '3');


