<?php
  error_reporting(E_ERROR); 
  ob_start(); 
  require_once('php/db_csat.php');

  session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

  require_once('php/kosarhoz_ad.php');
?>

<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html" charset="utf-8">

 
 
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>    
    

    <link rel="stylesheet" href="css/style.css" type="text/css" media="all"/>
</head>
    
  
    
<body>
    
    
  
<header>

  <div class="navigation btn-group">
      
      
    <button type="button" class="btn btn-secondary  disabled">FŐOLDAL</button>
      
    <button id="btKontakt" type="button" class="btn btn-secondary submit-button">KONTAKT</button>
      <script type="text/javascript">
            document.getElementById("btKontakt").onclick = function() 
            {
                location.href = "kontakt.php";
            };
      </script>
      
      
    <button id="btSugo" type="button" class="btn btn-secondary  submit-button">SÚGÓ</button>
      <script type="text/javascript">
            document.getElementById("btSugo").onclick = function() 
            {
                location.href = "segitseg.php";
            };
      </script>
      
      
    <button id="btProfil" type="button" class="btn btn-secondary  submit-button">PROFILOM</button>
      <script type="text/javascript">
            document.getElementById("btProfil").onclick = function() 
            {
                location.href = "auth/login.php";
            };
      </script>
      
      
   <button id="btRegisztral" type="button" class="btn btn-secondary  submit-button">REGISZTRÁLÁS</button>
      <script type="text/javascript">
            document.getElementById("btRegisztral").onclick = function() 
            {
                location.href = "auth/registration.php";
            };
      </script>
      
      
   <button id="btHirdet" type="button" class="btn btn-secondary submit-button">HÍRDETÉS FELTÖLTÉSE</button>
      <script type="text/javascript">
            document.getElementById("btHirdet").onclick = function() 
            {
                location.href = "feltolt.php";
            };
      </script>
      
    </div>

<br>
  <h1 class="text-center fw-bold display-1">Használt sportszer</h1>

  <p class="text-center display-6">Meg szeretne válni a feleslegessé vált sportcuccoktól? Mi segítünk! Töltse fel, adja el amit már nem használ!</p> 
</header>

        
        
<div id="iranyjelzo" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
      
    <div class="carousel-item active">
      <img src="css/images/kezdokepek/penz.jpg" alt="img1" class="d-block" style="width:100%">
      
    </div>

    <div class="carousel-item">
      <img src="css/images/kezdokepek/ugyfel.jpg" alt="img2" class="d-block" style="width:100%">
      </div> 
  
    
    <div class="carousel-item">  
      <img src="css/images/kezdokepek/sportok.jpg" alt="img3" class="d-block" style="width:100%">
    </div>
  
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#iranyjelzo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#iranyjelzo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
      
        <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#iranyjelzo" data-bs-slide-to="0" class="active"></button>
    <button class="btIranyjelzo" type="button" data-bs-target="#iranyjelzo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#iranyjelzo" data-bs-slide-to="2"></button>
  </div>
</div>
    
    </div> 
    
    
   
    <!--*****     Szűrések    *****--> 
    <br><br>
    
    <div class="container-fluid">
         <h2 class="text-center">Szűrési lehetőségek</h2><br>
          <p class="display-6">Állítson be szűrőket a hatékonyabb keresésért!</p>

        <div class="card-group">
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title ">Sportok szerint</h3>
              <form action="#" method="post">
                <br>
            <select id="sport" name="sport" class="form-control">
                    <option value="">...</option>
                    <option value="labdarúgás">Labdarúgás</option>
                    <option value="kézilabda">Kézilabda</option>
                    <option value="röplabda">Röplabda</option>
                    <option value="amerikaifoci">Amerikai foci</option>
                    <option value="atlétika">Atlétika</option>
                    <option value="kosárlabda">Kosárlabda</option>
                    <option value="tenisz">Tenisz</option>
                    <option value="vizesSportk">Vizes sportok</option>
                    <option value="telisportok">Téli sportok</option>
                <option value="szabadidoSportok">Szabadidő sportok</option></select>
        </form>
                </div>
            </div>
            
                    
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title ">Minimum ár</h3>
              <label for="price_min">Ft-tól:</label>
                    <input class="form-control form-control-sm" type="number" id="price_min" name="price_min" min="0"><br>
            </div>
            </div>  
            
            <br>
            
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title ">Maximum Ár</h3>
              <label for="price_min">Ft-tól:</label>
              <input class="form-control form-control-sm" type="number" id="price_max" name="price_max" min="0">
            </div>
            </div>  
            
            
        <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title ">Férfi/Női</h3>
              <form action="#" method="post">
                <br>
            <select id="neme" name="neme" class="form-control">
                    <option value="">...</option>
                    <option value="ferfi">Férfi</option>
                    <option value="no">Női</option>
                </select>
        </form>
                </div>
            </div>
            
            
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title ">Méret szerint</h3>
              <form action="#" method="post">
                <br>
            <select id="size" name="size" class="form-control">
                    <option value="">...</option>
                    <option value="gyerek">Gyerek</option>
                    <option value="felnőtS">Felnőt:S</option>
                    <option value="felnőtM">Felnőt:M</option>
                    <option value="felnőtL">Felnőt:L</option>
                    <option value="felnőtXL">Felnőt:XL</option>
                </select>
        </form>
                </div>
            </div>
            
            <br>
            
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title">Szín szerint</h3>
              <form action="#" method="post">
                <br>
             <select id="color" name="color" class="form-control">
                    <option value="">...</option>
                    <option value="piros">Piros</option>
                    <option value="kék">Kék</option>
                    <option value="zöld">Zöld</option>
                </select>
              </form>
                </div>
            </div>
            
            <br>
            
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title">Állapot szerint</h3>
              <form action="#" method="post">
                <br>
             <select id="allapot" name="allapot" class="form-control">
                    <option value="">...</option>
                    <option value="piros">Új</option>
                    <option value="kék">Használt</option>
                    <option value="zöld">mittomén találj ki valamit</option>
                </select>
              </form>
                </div>
            </div>
            
            <br>
            
            <div class="column">
            <div class="card bg-secondary  h-100">
              <h3 class="card-title">Típus szerint</h3>
              <form action="#" method="post">
                <br>
             <select id="tipus" name="tipus" class="form-control">
                    <option value="">...</option>
                    <option value="piros">Cipő</option>
                    <option value="kék">Póló</option>
                    <option value="zöld">Nadrág</option>
                </select>
              </form>
                </div>
            </div>
            
         </div>
         </div> <br>
     <input class="form-control bg-secondary text-white" type="submit" value="Szűrés">
    <br>

 <br>


    <!--*****    Hírdetések    *****-->
    
 
    <?php
      $show_products = $conn->prepare("SELECT * FROM `hirdetesek`");
      $show_products->execute();
      if($show_products->rowCount() > 0){
         while($fetch_products = $show_products->fetch(PDO::FETCH_ASSOC)){  
   ?>
 
        <div class="container-fluid">
        <h2 class="text-center">Elérhető Hírdetések</h2><br>
            <div class="card" style="width:400px">
                <img class="card-img-top" src="hirdetes_kepek/<?= $fetch_products['kep1']; ?>" alt="">
                <div class="card-body bg-secondary">
                    <h1 class="card-title name"><?= $fetch_products['marka'];?></h1>
                    
                    <h2 class="card-title name"><?= $fetch_products['marka']; ?> <?= $fetch_products['termektipus']; ?></h2>
                    <br>
                    <p class="card-text ">Leírás.asdasadasdasadasadasadasadasdasadasadasaddfasadasadasasasasasad</p>
                    <a href="#" class="btn btn-dark">Bővebben...</a>
                </div>
            </div>
        </div>

        <?php
         
        
        }
      }else{
         echo '<p class="empty">Nincs még feltöltve hírdetés!</p>';
      }
   ?>
    
    

    
    
    
    
    

    <!--*****    Footer    *****-->
    
    <footer id="footerStat">
     <div class="row align-items-center">  
   
   <div class="col">
      <h3 class="ico ico2 ">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
    </div>
    <div class="col">
      <h3 class="ico ico3 ">Ajándék</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
    </div>
  </div>
    </footer>

    
    
    
</body>
</html>
<?php
  ob_end_flush(); 
?>
