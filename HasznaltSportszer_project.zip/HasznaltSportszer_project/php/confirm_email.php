<?php

include 'db_csat.php';
include '../fizetes.php';

// Retrieve the user's email and order details from the database or form submission
$user_email = $_POST['email'];
$marka = $_POST['marka'];
$termektipus = $_POST['termektipus'];
$nem = $_POST['nem'];
$ossz_ar = $_POST['ossz_ar'];
$modszer = $_POST['modszer'];
$datum = $_POST['datum'];
$fizetes = $_POST['fizetes'];

// Set up the email subject and body
$subject = "Rendelés igazoló email";
$body = "Köszönjük a rendelését! Ez egy automatikus email kérjük ne válaszoljon rá!\n\n";
$body .= "A rendelés részletei:\n\n";
$body .= [$marka, $termektipus, $nem, $ossz_ar, $modszer, $datum, $fizetes];

// Set up the email headers
$headers = "A Használt Sportszer webshoptól <hasznalt_sportszerek@gmail.com>\r\n";
$headers .= "Content-type: text/plain; charset=utf-8\r\n";

// Send the email
if (mail($user_email, $subject, $body, $headers)) {
    echo "Igazoló email elküdlve a $user_email címre!";
} else {
    echo "Nem sikerült igazoló emailt küldeni!";
}

?>
