<?php

if(isset($_POST['add_to_cart'])){

   if($user_id == ''){
      header('location:../auth/login.php');
   }else{

      $termektipus = $_POST['termektipus'];
      $termektipus = filter_var($termektipus, FILTER_SANITIZE_STRING);
      $marka = $_POST['marka'];
      $marka = filter_var($marka, FILTER_SANITIZE_STRING);
      $ar = $_POST['ar'];
      $ar = filter_var($ar, FILTER_SANITIZE_STRING);
      $kep1 = $_POST['kep1'];
      $kep1 = filter_var($kep1, FILTER_SANITIZE_STRING);
      $kep2 = $_POST['kep2'];
      $kep2 = filter_var($kep2, FILTER_SANITIZE_STRING);
      $kep3 = $_POST['kep3'];
      $kep3 = filter_var($kep3, FILTER_SANITIZE_STRING);
      $kep4 = $_POST['kep4'];
      $kep4 = filter_var($kep4, FILTER_SANITIZE_STRING);
      $kep5 = $_POST['kep5'];
      $kep5 = filter_var($kep5, FILTER_SANITIZE_STRING);
      

      $check_cart_numbers = $conn->prepare("SELECT * FROM `cart` WHERE marka = ? AND user_id = ?");
      $check_cart_numbers->execute([$marka, $user_id]);

        $insert_cart = $conn->prepare("INSERT INTO `cart`(user_id, termektipus, marka, ar, kep1) VALUES(?,?,?,?,?)");
         $insert_cart->execute([$user_id, $termektipus, $marka, $ar, $kep1]);
         $message[] = 'Kosárhoz hozzáadva!';
         
      

   }

}

if(isset($message)){
   foreach($message as $message){
      echo '
      <div class="message">
         <span>'.$message.'</span>
         <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
      </div>
      ';
   }
}

?>