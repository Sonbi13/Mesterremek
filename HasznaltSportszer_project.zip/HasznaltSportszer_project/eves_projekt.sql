-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 23, 2023 at 08:51 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eves_projekt`
--
CREATE DATABASE IF NOT EXISTS `eves_projekt` DEFAULT CHARACTER SET utf8 COLLATE utf8_hungarian_ci;
USE `eves_projekt`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `name` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`) VALUES
(2, 'Ádi', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(5, 'sonbi', '8cb2237d0679ca88db6464eac60da96345513964');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(10) NOT NULL,
  `image` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `user_id`, `name`, `price`, `quantity`, `image`) VALUES
(1, 7, 'Nike', 20000, 1, '1017524.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `felhasznalo`
--

CREATE TABLE `felhasznalo` (
  `id` int(4) NOT NULL,
  `name` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `number` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `felhasznalo`
--

INSERT INTO `felhasznalo` (`id`, `name`, `email`, `number`, `password`, `address`) VALUES
(7, 'Dominik', 'domy.sonby@gmail.com', '0620230006', '2891baceeef1652ee698294da0e71ba78a2a4064', 'francia, anyamkinja, 1231234, fasz, 12, 11'),
(15, 'csanad', 'csanad@gmail.com', '062061312', 'a59ca26e00d4ce3f0ad77351266df1fc5bbcf91f', 'észak-korea, , , , , ');

-- --------------------------------------------------------

--
-- Table structure for table `hirdetesek`
--

CREATE TABLE `hirdetesek` (
  `id` int(100) NOT NULL,
  `allapot` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `marka` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `nem` varchar(10) COLLATE utf8_hungarian_ci NOT NULL,
  `sportag` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `szin` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `termektipus` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `ar` int(10) NOT NULL,
  `leiras` varchar(500) COLLATE utf8_hungarian_ci NOT NULL,
  `kep1` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `kep2` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `kep3` varchar(1001) COLLATE utf8_hungarian_ci NOT NULL,
  `kep4` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `kep5` varchar(100) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Dumping data for table `hirdetesek`
--

INSERT INTO `hirdetesek` (`id`, `allapot`, `marka`, `nem`, `sportag`, `szin`, `termektipus`, `ar`, `leiras`, `kep1`, `kep2`, `kep3`, `kep4`, `kep5`) VALUES
(1, 'Használt', 'Nike', 'Női', 'Labdarúgás', 'piros', 'cipő', 20000, 'jasdjascjnasjkfusakjcnsajkfkbjksfjkakjfjsfkj', '2720813.jpg', '1017524.jpg', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `rendelesek`
--

CREATE TABLE `rendelesek` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `nev` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `telszam` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `modszer` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `cim` varchar(500) COLLATE utf8_hungarian_ci NOT NULL,
  `ossz_rendeles` varchar(1000) COLLATE utf8_hungarian_ci NOT NULL,
  `ossz_ar` int(100) NOT NULL,
  `datum` date NOT NULL DEFAULT current_timestamp(),
  `fizetes` varchar(30) COLLATE utf8_hungarian_ci NOT NULL DEFAULT 'fizetés nem történt meg'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

-- --------------------------------------------------------

--
-- Table structure for table `uzenetek`
--

CREATE TABLE `uzenetek` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_hungarian_ci NOT NULL,
  `number` varchar(20) COLLATE utf8_hungarian_ci NOT NULL,
  `message` varchar(500) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `felhasznalo`
--
ALTER TABLE `felhasznalo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hirdetesek`
--
ALTER TABLE `hirdetesek`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rendelesek`
--
ALTER TABLE `rendelesek`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uzenetek`
--
ALTER TABLE `uzenetek`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `felhasznalo`
--
ALTER TABLE `felhasznalo`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `hirdetesek`
--
ALTER TABLE `hirdetesek`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `rendelesek`
--
ALTER TABLE `rendelesek`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `uzenetek`
--
ALTER TABLE `uzenetek`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
