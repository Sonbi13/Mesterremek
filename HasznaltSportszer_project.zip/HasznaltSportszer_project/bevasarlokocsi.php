<?php

include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:index.php');
};

if(isset($_POST['delete'])){
   $cart_id = $_POST['cart_id'];
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$cart_id]);
   $message[] = 'Kosárbol törölve!';
}

if(isset($_POST['delete_all'])){
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart_item->execute([$user_id]);
   $message[] = 'Kosár tartalma törölve!';
}

if(isset($_POST['update_qty'])){
   $cart_id = $_POST['cart_id'];
   $qty = $_POST['qty'];
   $qty = filter_var($qty, FILTER_SANITIZE_STRING);
   $update_qty = $conn->prepare("UPDATE `cart` SET quantity = ? WHERE id = ?");
   $update_qty->execute([$qty, $cart_id]);
   $message[] = 'A mennyiség megváltozott!';
}

$grand_total = 0;

?>


<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a href="#">Bevásárló kocsi</a></h1>
    
    <div id="cart"> <a href="#" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.php">Főoldal</a></li>
        <li><a href="Segitseg" >Segítség</a></li>
        <li><a href="elerhetosegek.html">Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
    <?php
         $grand_total = 0;
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
      ?>

<div class="sub-total"> Termék ára: <span>$<?= $sub_total = ($fetch_cart['price'] * $fetch_cart['quantity']); ?></span> </div>
      
      <?php
               $grand_total += $sub_total;
            }
         }else{
            echo '<p>A kosara üres</p>';
         }
      ?>

   </div>

   <div>
      <p>Kosár tartalom ára : <span><?= $grand_total; ?>Ft</span></p>
      <a href="fizetes.php" class="btn <?= ($grand_total > 1)?'':'disabled'; ?>">Tovább a fizetéshez</a>
   </div>

   <div class="more-btn">
      <form action="" method="post">
         <button type="submit" <?= ($grand_total > 1)?'':'disabled'; ?>" name="delete_all" onclick="return confirm('kitröli ezt a kosárból?);">Kosár tartalmának törlése</button>
      </form>
      <a href="index.php">Vásárlás folytatása</a>
   </div>


    
    <div class="cl">&nbsp;</div>
  </div>
  
  <div class="side-full">

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="index.php">Főoldal</a> <span>|</span> <a href="Segitseg.html">Segítség</a> <span>|</span> <a href="elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>

<script src="js/script.js"></script>

</body>
</html>