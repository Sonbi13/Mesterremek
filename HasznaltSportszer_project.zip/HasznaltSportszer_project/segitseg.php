<?php
include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['send'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING);

   $select_message = $conn->prepare("SELECT * FROM `uzenetek` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

       $insert_message = $conn->prepare("INSERT INTO `uzenetek`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message[] = 'Üzenetét sikeresen elküldte!';

   

}

if(isset($message)){
    foreach($message as $message){
       echo '
       <div class="message">
          <span>'.$message.'</span>
          <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
       </div>
       ';
    }
 }

?>

<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Súgó</title>
<meta http-equiv="Content-type" content="text/html" charset="utf-8">

 
 
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>    
    

    <link rel="stylesheet" href="css/style.css" type="text/css" media="all"/>
</head>
    
  
    
<body>
    
    
  
<header>

  <div class="navigation btn-group">
      
      
    <button id="btIndex" type="button" class="btn btn-secondary  submit-button">FŐOLDAL</button>
    <script type="text/javascript">
          document.getElementById("btIndex").onclick = function() 
          {
              location.href = "index.php";
          };
    </script>
      
    <button id="btKontakt" type="button" class="btn btn-secondary submit-button">KONTAKT</button>
      <script type="text/javascript">
            document.getElementById("btKontakt").onclick = function() 
            {
                location.href = "kontakt.php";
            };
      </script>
      
      
      <button type="button" class="btn btn-secondary  disabled">Súgó</button>
      
      
    <button id="btProfil" type="button" class="btn btn-secondary  submit-button">PROFILOM</button>
      <script type="text/javascript">
            document.getElementById("btProfil").onclick = function() 
            {
                location.href = "auth/login.php";
            };
      </script>
      
      
   <button id="btRegisztral" type="button" class="btn btn-secondary  submit-button">REGISZTRÁLÁS</button>
      <script type="text/javascript">
            document.getElementById("btRegisztral").onclick = function() 
            {
                location.href = "auth/registration.php";
            };
      </script>
      
      
   <button id="btHirdet" type="button" class="btn btn-secondary submit-button">HÍRDETÉS FELTÖLTÉSE</button>
      <script type="text/javascript">
            document.getElementById("btHirdet").onclick = function() 
            {
                location.href = "feltolt.php";
            };
      </script>
      
    </div>

<br>
  <h1 class="text-center fw-bold display-1">Súgó</h1>

  <p class="text-center display-6">******Súgó alcím*****</p> 
</header>






<footer id="footerFix">
  <div class="row align-items-center">  

  <div class="col">
      <h3 class="ico ico2">Elérhetőségek</h3>
      <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
  </div>
  <div class="col">
      <h3 class="ico ico3">Ajándék</h3>
      <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
  </div>
  </div>
  </footer>




  </body>
</html>
