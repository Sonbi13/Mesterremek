<?php

include 'php/db_csat.php';
//include 'php/confirm_email.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
};

if(isset($_POST['submit'])){

   $nev = $_POST['nev'];
   $nev = filter_var($nev, FILTER_SANITIZE_STRING);
   $telszam = $_POST['telszam'];
   $telszam = filter_var($telszam, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $modszer = $_POST['modszer'];
   $modszer  = filter_var($modszer, FILTER_SANITIZE_STRING);
   $cim = $_POST['cim'];
   $cim = filter_var($cim, FILTER_SANITIZE_STRING);
   $ossz_rendeles = $_POST['ossz_rendeles'];
   $ossz_ar = $_POST['ossz_ar'];

   $check_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
   $check_cart->execute([$user_id]);

   if($check_cart->rowCount() > 0){

      if($cim == ''){
         $message[] = 'Kérem adja meg a kiszállítási címet!';
      }else{
         
         $insert_order = $conn->prepare("INSERT INTO `rendelesek`(user_id, nev, telszam, email, modszer, cim, ossz_rendeles, ossz_ar VALUES(?,?,?,?,?,?,?,?)");
         $insert_order->execute([$user_id, $nev, $telszam, $email, $modszer, $cim, $ossz_rendeles, $ossz_ar]);

         $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
         $delete_cart->execute([$user_id]);

         $message[] = 'Rendelését sikeresen leadta!';
      }
      
   }else{
      $message[] = 'A kosara üres';
   }

}

if(isset($message)){
    foreach($message as $message){
       echo '
       <div class="message">
          <span>'.$message.'</span>
          <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
       </div>
       ';
    }
 }

 $select_profile = $conn->prepare("SELECT * FROM `felhasznalo` WHERE id = ?");
            $select_profile->execute([$user_id]);
            if($select_profile->rowCount() > 0){
               $fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
              };

?>
<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Elérhetőségek</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.php" >Főoldal</a></li>
        <li><a href="segitseg.php">Segítség</a></li>
        <li><a>Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">
      
     
     
      
    </div>
    
    <div id="sidebar">
    
     
        <div id="valami">
            
            
            
        <h1 class="title">Rendelés összegzés</h1>

<form action="" method="post">

   <div>
      <h3>Kosár tartalma</h3>
      <?php
         $grand_total = 0;
         $cart_items[] = '';
         $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
         $select_cart->execute([$user_id]);
         if($select_cart->rowCount() > 0){
            while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
               $cart_items[] = $fetch_cart['name'].' ('.$fetch_cart['price'].'';
               $total_products = implode($cart_items);
               $grand_total += ($fetch_cart['price']);
      ?>
      <p><span><?= $fetch_cart['name']; ?></span><span><?= $fetch_cart['price']; ?> Ft </span></p>
      <?php
            }
         }else{
            echo '<p class="empty">A kosara üres!</p>';
         }
      ?>
      <p><span>Kosara összege :</span><span><?= $grand_total; ?>Ft</span></p>
      <a href="bevasarlokocsi.php">Kosár megnézése</a>
   </div>

   <input type="hidden" name="ossz_rendeles" value="<?= $total_products; ?>">
   <input type="hidden" name="ossz_ar" value="<?= $grand_total; ?>" value="">
   <input type="hidden" name="nev" value="<?= $fetch_profile['name'] ?>">
   <input type="hidden" name="telszam" value="<?= $fetch_profile['number'] ?>">
   <input type="hidden" name="email" value="<?= $fetch_profile['email'] ?>">
   <input type="hidden" name="cim" value="<?= $fetch_profile['address'] ?>">

   <div>
      <h3>Az ön adatai</h3>
      <p><span><?= $fetch_profile['name'] ?></span></p>
      <p><span><?= $fetch_profile['number'] ?></span></p>
      <p><span><?= $fetch_profile['email'] ?></span></p>
      <a href="profil_valtoztatas.php">Adatok megváltoztatása</a>
      <h3>Kiszállítási cím</h3>
      <p><span><?php if($fetch_profile['address'] == ''){echo 'Adja meg a címét';}else{echo $fetch_profile['address'];} ?></span></p>
      <a href="profil_cim.php">Kiszállítási cím megváltoztatása</a>
      <select name="modszer"required>
         <option value="" disabled selected>Fizetési mód</option>
         <option value="készpénz">Készpénz</option>
         <option value="bankkártya">Bankkártya</option>
         <option value="Revolut">Revolut</option>
         <option value="Paypal">Paypal</option>
      </select>
      <input type="submit" value="Rendelés leadása" class="btn <?php if($fetch_profile['address'] == ''){echo 'disabled';} ?>" style="width:100%; background:var(--red); color:var(--white);" name="submit">
   </div>

</form>

        </div>
      </div>

 
  
  
    
    
   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  
  
  <div id="footer">
    <p class="left"> <a href="index.php">Főoldal</a> <span>|</span> <a href="Segitseg.html">Segítség</a></p>
    <p class="right"> A weboldal ami fellendíti a sport karriered!</p>
  </div>
  
</div>
<script src="js/script.js"></script>
    </div>
</body>
</html>
