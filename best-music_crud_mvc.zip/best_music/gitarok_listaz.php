<?php
    require_once('header.php');
    require_once('functions/func_gitarok_listaz.php');
    require_once('functions/func_gitar_kategoriak.php');
    $gitarok = gitarok_lekerdez();
    $gitar_kategoriak = gitar_kategoriak_lekerdez();
   //echo '<pre>';
   //var_dump($gitarok);
   //echo '</pre>';
   
?>
<div class="container mt-3">
    <table class="table table-hover">
        <thead>
            <th>ID</th>
            <th>Gyártó</th>
            <th>Tipus</th>
            <th>kategoria_id</th>
            <th>hurok_szama</th>
            <th>ar</th>
            <th>raktar_mennyiseg</th>
            <th>allapot</th>
            <th>Műveletek</th>
        </thead>
        <tbody>
             <?php
             foreach ($gitarok as $gitar){
                
                     
                 
                echo "<tr>";
                    echo "<td>". $gitar['id']. "</td>";
                    echo "<td>". $gitar['gyarto']. "</td>";
                    echo "<td>". $gitar['tipus']. "</td>";
                    echo "<td>". $gitar['kategoria_id']. "</td>";
                    echo "<td>". $gitar['hurok_szama']. "</td>";
                    echo "<td>". $gitar['ar']. "</td>";
                    echo "<td>". $gitar['raktar_mennyiseg'] ."</td>";
                    echo "<td>";
                    if ($gitar['allapot'] == 1) {
                        echo "Aktív";
                    }
                    else {
                        echo "Inaktív";
                    }
                        
                    echo "</td>";
                    echo "<td>";
                        echo '<a class="btn btn-warning" href="gitar_modosit.php?id='. $gitar['id'].'"> Módosít </a> ';
                        echo '<a class="btn btn-danger" href="gitar_torol.php?id='. $gitar['id'].'"> Töröl </a>';
                    echo "</td>";
                echo "</tr>";
                  
             }
             ?>
        </tbody>   
    </table>



    <select name="kategoria_id" id="kategoria_id" class="form-select">
                            <?php
                            $selected = ""; 
                            foreach ($gitar_kategoriak as $gitar_kategoria) {
                                //Ha az gitar_kategoria idja megegyezik az aktuálisan kiválasztott gitarnak a kategória_idjával, akkor megkapja az 
                                //option a selected tulajdonságot
                            
                                echo "<option value=".$gitar_kategoria['id']." $selected>".$gitar_kategoria['nev']."</option>";
                            }
                            ?>
                        </select>
    <a class="btn btn-primary" href="gitar_uj.php">Új gitár felvitel</a>         
    <a class="btn btn-primary" href="gitar_legdragabb.php">Legdárább gitárok</a> 
    
  

</div>
</body>
</html>



