<?php
    require_once('db_connect.php');

    function gitar_felvitel(){
        $mysqli = db_connect();
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $kategoria_id = $_POST['kategoria_id'];
        $hurok_szama = $_POST['hurok_szama'];
        $ar = $_POST['ar'];
        $raktar_mennyiseg = $_POST['raktar_mennyiseg'];
        if (isset($_POST['allapot'])){
            $allapot = 1;
        } else {
            $allapot = 0;
        }
        $sql = "INSERT INTO gitarok (gyarto,tipus,kategoria_id,hurok_szama,ar, raktar_mennyiseg, allapot) 
        VALUES ('$gyarto','$tipus', '$kategoria_id','$hurok_szama','$ar','$raktar_mennyiseg','$allapot')";
        $eredmeny = $mysqli->query($sql);
    
        //Ha sikeres az sql insert, akkor átirányít a főoldalra
        if ($eredmeny) {
            // . kijövünk a gyökér mappába, ahol az index.php található
            $url = './index.php';
            header('Location: ' . $url);
            } else {   
                echo $mysqli->error;
        } 
        mysqli_close($mysqli);
    }
?>