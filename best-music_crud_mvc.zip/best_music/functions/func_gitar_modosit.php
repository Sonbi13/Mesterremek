<?php
    require_once('db_connect.php');

    function gitar_lekerdez_id_alapjan($id){
        $mysqli = db_connect();
        $sql = "SELECT * FROM `gitarok` WHERE `id` = '$id'";
        $eredmeny = $mysqli->query($sql);
        $gitar = mysqli_fetch_assoc($eredmeny);
        return $gitar;
    }

    function gitar_modosit(){

        $mysqli = db_connect();
        $id = $_POST['id'];
        $gyarto = $_POST['gyarto'];
        $tipus = $_POST['tipus'];
        $kategoria_id = $_POST['kategoria_id'];
        $hurok_szama = $_POST['hurok_szama'];
        $ar = $_POST['ar'];
        $raktar_mennyiseg = $_POST['raktar_mennyiseg'];
        if (isset($_POST['allapot'])){
            $allapot = 1;
        } else {
            $allapot = 0;
        }

        $sql = "UPDATE `gitarok` SET `gyarto` = '$gyarto',
        `tipus` = '$tipus',`kategoria_id` = '$kategoria_id', 
        `hurok_szama` = '$hurok_szama',`ar` = '$ar',`raktar_mennyiseg` = '$raktar_mennyiseg',
        `allapot` = '$allapot' WHERE `id`='$id'";

        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            $url = "index.php";
            header('Location: ' . $url);
        } else {
            echo $mysqli->error;
        }
        mysqli_close($mysqli);
    }
?>