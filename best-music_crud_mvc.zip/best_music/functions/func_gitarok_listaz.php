<?php
    require_once('db_connect.php');

    //Figyeljünk oda arra, hogyha azonos egy oszlopnév, akkor nem mindig a megfelelő táblából veszi az adatot
    function gitarok_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT a.id, a.gyarto, a.tipus, a.kategoria_id, a.hurok_szama, a.ar, a.raktar_mennyiseg, a.allapot FROM gitarok as a INNER JOIN gitar_kategoriak as ak ON a.kategoria_id = ak.id";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $gitarok[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $gitarok;
    }
?>