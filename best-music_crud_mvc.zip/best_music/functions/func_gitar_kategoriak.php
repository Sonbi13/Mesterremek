<?php
    require_once('db_connect.php');

    //procedurális függvény
    function gitar_kategoriak_lekerdez(){
        $mysqli = db_connect();
        $sql = "SELECT * FROM gitar_kategoriak";
        $eredmeny = $mysqli->query($sql);
        if ($eredmeny){
            while ($sor = mysqli_fetch_assoc($eredmeny)){
                $gitar_kategoriak[] = $sor;
            }
        } else {
            die("SQL hiba: ".$mysqli->error);
        }
        mysqli_close($mysqli);
    return $gitar_kategoriak;
    }
?>