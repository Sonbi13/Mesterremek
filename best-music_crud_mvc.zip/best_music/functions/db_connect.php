<?php
    header('Content-Type: text/html; charset=utf-8');

    //függvény deklaráció, használatához meg is kell hívni
    function db_connect(){
        //sorrenben a paraméterek: hostnév, felhasználó, jelszó, ab_név
        $mysqli = new mysqli("localhost","root", "", "best_music");
        if (!$mysqli){
            die("Nem lehet csatlakozni az adatbázishoz!!!".$mysqli->error);
        }
    return $mysqli;
    }
?>