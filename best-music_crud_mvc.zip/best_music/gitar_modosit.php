<?php
    require_once('header.php');
    require_once('functions/func_gitar_modosit.php');
    require_once('functions/func_gitar_kategoriak.php');
 
    //URL-ből begyűjtjuk az id-t
    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    $gitar_kategoriak = gitar_kategoriak_lekerdez();

    $gitar = gitar_lekerdez_id_alapjan($id);

    //echo '<pre>';
    //var_dump($gitar);
    //echo '</pre>';

    //ha a mentés gombra kattintottunk
    if (isset($_POST['modosit'])){
        gitar_modosit(); 
    }

?>
<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-sm-6">
                    <div class="form-group">
                        <label for="gyarto">Gyártó</label>
                        <input type="text" class="form-control" name="gyarto" id="gyarto" value="<?php echo $gitar['gyarto']; ?>" placeholder="Gyártó" required>
                    </div> 
                    <div class="form-group">
                        <label for="tipus">Típus</label>
                        <input type="text" class="form-control" value="<?php echo $gitar['tipus']; ?>" name="tipus" id="tipus" placeholder="Típus" required>
                    </div> 
                    <div class="form-group">
                        <label for="kategoria_id">Kategóriák</label>
                        <select name="kategoria_id" id="kategoria_id" class="form-select">
                            <?php
                            $selected = ""; 
                            foreach ($gitar_kategoriak as $gitar_kategoria) {
                                //Ha az gitar_kategoria idja megegyezik az aktuálisan kiválasztott gitarnak a kategória_idjával, akkor megkapja az 
                                //option a selected tulajdonságot
                                $gitar_kategoria['id'] == $gitar['kategoria_id'] ? $selected = "selected" : $selected = "";
                                echo "<option value=".$gitar_kategoria['id']." $selected>".$gitar_kategoria['nev']."</option>";
                            }
                            ?>
                        </select>
                    </div> 
                    <div class="form-group">
                        <label for="hurok_szama">Húrok száma</label>
                        <input type="number" class="form-control" name="hurok_szama" id="hurok_szama" value="<?php echo $gitar['hurok_szama']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="ar">Nettó ár (Ft)</label>
                        <input type="number" value="<?php echo $gitar['ar']; ?>"class="form-control" name="ar" id="ar" required>
                    </div>
            
                    <div class="form-group">
                        <label for="raktar_mennyiseg">Raktár mennyiseg</label>
                        <input type="number" value="<?php echo $gitar['raktar_mennyiseg']; ?>"class="form-control" name="raktar_mennyiseg" id="raktar_mennyiseg" required>
               
                    </div>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="allapot" id="allapot" <?php $gitar['allapot'] == 1 ? print "checked" : print "";?>>
                        <label class="form-check-label" for="allapot">
                           Állapot
                        </label>
                    </div>
                    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 
                    <input type="submit" name="modosit" value="MÓDOSÍT" class="btn btn-success mt-3">
            </div> 
            </form>
        </div> 
    </div> 
</div>
</body>
</html>