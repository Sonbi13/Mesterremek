<?php
    require_once('header.php');
    require_once('functions/func_gitar_torol.php');

    if (isset($_GET['id'])){
        $id = $_GET['id'];
    }

    //ha a töröl gombra kattintottunk
    if (isset($_POST['torol'])){
        gitar_torol(); 
    }

?>

<div class="container mt-3">
    <div class="row">
        <div class="col-sm-12">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <div class="row">
                <div class="col-sm-6">
                    <div class="form-group">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                        <p>Tényleg törli: <?php echo $id; ?></p>              
                        <a href="javascript:history.back()" class="btn btn-warning">Mégsem</a> 
                        <input type="submit" name="torol" value="Töröl" class="btn btn-danger">
                    </div>  
                </div> 
            </div> 
            </form>
        </div> 
    </div> 
</div>
</body>
</html>