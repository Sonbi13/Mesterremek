<?php
    require_once('header.php');
    require_once('functions/func_legdragabb.php');
    $sqlek = legdragabb_lekerdez();
 

 
    
   //echo '<pre>';
   //var_dump($gitarok);
   //echo '</pre>';
   
?>
<div class="container mt-3">
    <table class="table table-hover">
        <thead>
            <th>ID</th>
            <th>Gyártó</th>
            <th>Tipus</th>
            <th>kategoria_id</th>
            <th>hurok_szama</th>
            <th>ar</th>
            <th>raktar_mennyiseg</th>
            <th>allapot</th>
        </thead>


        <tbody>
            
        
             <?php


                 foreach ($sqlek as $sql){
               

                echo "<tr>";
                    echo "<td>". $sql['id']. "</td>";
                    echo "<td>". $sql['gyarto']. "</td>";
                    echo "<td>". $sql['tipus']. "</td>";
                    echo "<td>". $sql['kategoria_id']. "</td>";
                    echo "<td>". $sql['hurok_szama']. "</td>";
                    echo "<td>". $sql['ar']. "</td>";
                    echo "<td>". $sql['raktar_mennyiseg'] ."</td>";
                    echo "<td>";
                    if ($sql['allapot'] == 1) {
                        echo "Aktív";
                    }
                    else {
                        echo "Inaktív";
                    }
                        
             }
             ?>
        </tbody>   
    </table>
    <a href="javascript:history.back()" class="btn btn-warning mt-3">Mégsem</a> 

</div>
</body>
</html>


