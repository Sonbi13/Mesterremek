<?php



if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
};

$email = $_POST['email'];
$email = filter_var($email, FILTER_SANITIZE_STRING);
//$termektipus = $_POST['termektipus'];
      //$termektipus = filter_var($termektipus, FILTER_SANITIZE_STRING);
      //$marka = $_POST['marka'];
      //$marka = filter_var($marka, FILTER_SANITIZE_STRING);
      //$ar = $_POST['ar'];
      //$ar = filter_var($ar, FILTER_SANITIZE_STRING);
      //$kep1 = $_POST['kep1'];
      //$kep1 = filter_var($kep1, FILTER_SANITIZE_STRING);

$to = $email;


$subject = "Rendelést igazoló email";


$message = "Kedves vásárlónk!,\n\nKöszönjük a vásárlást! A rendelését megkaptuk és elkezdtük a feldolgozását!\n\nOrder Details:\nRendelés időpontja: ".date("Y-m-d H:i:s")."\n\nKöszönjük a bizalmat!\n\nTsiztelettel,\nA Használt Sportszer csapata";


$headers = "From: hasznalt_sportszer@gmail.com\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();


mail($to, $subject, $message, $headers);
?>
