<?php

include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:auth/login.php');
};

if(isset($_POST['delete'])){
   $cart_id = $_POST['cart_id'];
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE id = ?");
   $delete_cart_item->execute([$cart_id]);
   $message[] = 'Termék törölve a kosárból!';
}

if(isset($_POST['delete_all'])){
   $delete_cart_item = $conn->prepare("DELETE FROM `cart` WHERE user_id = ?");
   $delete_cart_item->execute([$user_id]);
   
   $message[] = 'Kosár kiürítve';
}
$grand_total = 0;

if(isset($message)){
    foreach($message as $message){
       echo '
       <div class="message">
          <span>'.$message.'</span>
          <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
       </div>
       ';
    }
 }

?>

<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Elérhetőségek</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.php" >Főoldal</a></li>
        <li><a href="Segitseg.html">Segítség</a></li>
        <li><a>Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">
      
     
     
      
    </div>
    
    <div id="sidebar">
    
     
        <div id="valami">
            
            
            
        

<h1 class="title">Kosár</h1>

<div class="box-container">

   <?php
      $grand_total = 0;
      $select_cart = $conn->prepare("SELECT * FROM `cart` WHERE user_id = ?");
      $select_cart->execute([$user_id]);
      if($select_cart->rowCount() > 0){
         while($fetch_cart = $select_cart->fetch(PDO::FETCH_ASSOC)){
   ?>
   <form action="" method="post" class="box">
      <input type="hidden" name="cart_id" value="<?= $fetch_cart['id']; ?>">
      <button type="submit" class="fas fa-times" name="delete" onclick="return confirm('Törli ezt a terméket?');">Termék törlése</button>
      <img src="hirdetes_kepek/<?= $fetch_cart['kep1']; ?>" alt="">
      <div class="name"><?= $fetch_cart['marka']; ?></div>
      <div class="name"><?= $fetch_cart['termektipus']; ?></div>
      <div class="flex">
         <div><?= $fetch_cart['ar']; ?><span>Ft</span></div>
         
      </div>
      </form>
   <?php
           
         }
      }else{
         echo '<p class="empty">A kosara üres</p>';
      }
   ?>

</div>

<div>
   <a href="fizetes.php">Tovább a fizetéshez</a>
</div>

<div class="more-btn">
   <form action="" method="post">
      <button type="submit" name="delete_all" onclick="return confirm('KIüríti a kosarat?');">Kosár kiürítése</button>
   </form>
   <a href="index.php" class="btn">Vissza a vásárláshoz</a>
</div>



        </div>
      </div>

 
  
  
    
    
   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  
  
  <div id="footer">
    <p class="left"> <a href="index.php">Főoldal</a> <span>|</span> <a href="Segitseg.html">Segítség</a></p>
    <p class="right"> A weboldal ami fellendíti a sport karriered!</p>
  </div>
  
</div>
<script src="js/script.js"></script>

</body>
</html>
