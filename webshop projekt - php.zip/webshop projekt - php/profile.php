<?php

include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:auth/login.php');
};

$select_profile = $conn->prepare("SELECT * FROM `felhasznalo` WHERE id = ?");
$select_profile->execute([$user_id]);
if($select_profile->rowCount() > 0){
$fetch_profile = $select_profile->fetch(PDO::FETCH_ASSOC);
};

?>

<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Elérhetőségek</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.html" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.php" >Főoldal</a></li>
        <li><a href="Segitseg.html">Segítség</a></li>
        <li><a>Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">
      
     
     
      
    </div>
    
    <div id="sidebar">
    
     
        <div id="valami">
            
            
            
        <section class="user-details">

<div class="user">
 
   <p><i class="fas fa-user"></i><span><span><?= $fetch_profile['name']; ?></span></span></p>
   <p><i class="fas fa-phone"></i><span><?= $fetch_profile['number']; ?></span></p>
   <p><i class="fas fa-envelope"></i><span><?= $fetch_profile['email']; ?></span></p>
   <a href="profil_valtoztatas.php" class="btn">Adatok frissítése</a>
   <p class="address"><i class="fas fa-map-marker-alt"></i><span><?php if($fetch_profile['address'] == ''){echo 'Kérem adja meg a címét';}else{echo $fetch_profile['address'];} ?></span></p>
   <a href="profil_cim.php" class="btn">Kiszállítási cím megváltoztatása</a>
   <a href="profil_kijelentkezes.php" class="btn">Kijelentkezés</a>
</div>

</section>

        </div>
      </div>

 
  
  
    
    
   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  
  
  <div id="footer">
    <p class="left"> <a href="index.php">Főoldal</a> <span>|</span> <a href="Segitseg.html">Segítség</a></p>
    <p class="right"> A weboldal ami fellendíti a sport karriered!</p>
  </div>
  
</div>
<script src="js/script.js"></script>

</body>
</html>













