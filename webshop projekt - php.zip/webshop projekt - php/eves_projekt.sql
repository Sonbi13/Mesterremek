

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `allapot` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(30) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `felhasznalo` (
  `id` int(4) NOT NULL,
  `felhasznalonev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `vezeteknev` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `keresztnev` varchar(30) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_hungarian_ci NOT NULL,
  `telefonszam` varchar(60) COLLATE utf8_hungarian_ci NOT NULL,
  `jelszo` varchar(60) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `hirdetesek` (
  `id` int(4) NOT NULL,
  `sportag.id` tinyint(4) NOT NULL,
  `marka.id` tinyint(4) NOT NULL,
  `termektipus.id` tinyint(4) NOT NULL,
  `ar` int(11) NOT NULL,
  `meret` varchar(6) COLLATE utf8_hungarian_ci NOT NULL,
  `szin.id` tinyint(4) NOT NULL,
  `allapot.id` tinyint(4) NOT NULL,
  `nem.id` tinyint(4) NOT NULL,
  `felhasznalo.id` int(4) NOT NULL,
  `datum` datetime NOT NULL,
  `megjegyzes` varchar(300) COLLATE utf8_hungarian_ci NOT NULL,
  `eleheto_e` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `marka` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(30) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `nem` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(30) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `sportag` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(50) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;



CREATE TABLE `szin` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(40) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;


CREATE TABLE `termektipus` (
  `id` tinyint(4) NOT NULL,
  `megnevezes` varchar(60) COLLATE utf8_hungarian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;


ALTER TABLE `allapot`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `felhasznalo`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `hirdetesek`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sportag.id` (`sportag.id`),
  ADD KEY `marka.id` (`marka.id`),
  ADD KEY `termektipus.id` (`termektipus.id`),
  ADD KEY `szin.id` (`szin.id`),
  ADD KEY `allapot.id` (`allapot.id`),
  ADD KEY `nem.id` (`nem.id`),
  ADD KEY `felhasznalo.id` (`felhasznalo.id`);


ALTER TABLE `marka`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `nem`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `sportag`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `szin`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `termektipus`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `allapot`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `felhasznalo`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `hirdetesek`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `marka`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `nem`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `sportag`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;

ALTER TABLE `szin`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `termektipus`
  MODIFY `id` tinyint(4) NOT NULL AUTO_INCREMENT;


ALTER TABLE `allapot`
  ADD CONSTRAINT `allapot_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`allapot.id`);


ALTER TABLE `felhasznalo`
  ADD CONSTRAINT `felhasznalo_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`felhasznalo.id`);


ALTER TABLE `marka`
  ADD CONSTRAINT `marka_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`marka.id`);


ALTER TABLE `nem`
  ADD CONSTRAINT `nem_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`nem.id`);


ALTER TABLE `sportag`
  ADD CONSTRAINT `sportag_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`sportag.id`);


ALTER TABLE `szin`
  ADD CONSTRAINT `szin_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`szin.id`);


ALTER TABLE `termektipus`
  ADD CONSTRAINT `termektipus_ibfk_1` FOREIGN KEY (`id`) REFERENCES `hirdetesek` (`termektipus.id`);
COMMIT;


