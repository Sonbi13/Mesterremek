<?php

include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
   header('location:index.php');
};

if(isset($_POST['submit'])){

   $address = $_POST['ország'] .', '.$_POST['megye'].', '.$_POST['irszám'].', '.$_POST['település'] .', '. $_POST['házszám'] .', '. $_POST['ajtó'];
   $address = filter_var($address, FILTER_SANITIZE_STRING);

   $update_address = $conn->prepare("UPDATE `felhasznalo` set address = ? WHERE id = ?");
   $update_address->execute([$address, $user_id]);

   $message[] = 'Cím elmentve!';

}

if(isset($message)){
  foreach($message as $message){
     echo '
     <div class="message">
        <span>'.$message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>
     ';
  }
}

?>
<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Segítség</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.html">Főoldal</a></li>
        <li><a>Segítség</a></li>
        <li><a href="elerhetosegek.html">Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">
    

<form action="" method="post">
   <h3>Kiszállítási cím</h3>
   
   <input type="text" class="box" placeholder="ország" required maxlength="50" name="ország">
   <input type="text" class="box" placeholder="megye" required maxlength="50" name="megye">
   <input type="text" class="box" placeholder="irányítószám" required maxlength="50" name="irszám">
   <input type="text" class="box" placeholder="település" required maxlength="50" name="település">
   <input type="text" class="box" placeholder="házszám" required maxlength="50" name="házszám">
   <input type="text" class="box" placeholder="ajtó szám"  name="ajtó">
   <input type="submit" value="save address" name="submit" class="btn">
</form>


      </div>
    
    
  
  <div class="side-full">
    

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="index.html">Főoldal</a><span>|</span> <a href="elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>
<script src="js/script.js"></script>

</body>
</html>
