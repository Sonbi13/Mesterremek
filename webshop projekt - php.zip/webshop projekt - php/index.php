<?php
  error_reporting(E_ERROR); 
  ob_start(); 
  require_once('php/db_csat.php');
  include('php/kosarhoz_ad.php');
  

  session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};


  


?>
<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
</head>
<body>
<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Használt Sportszer</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a>
                    <a href="feltolt.php" id="post">Hírdetés feltöltése</a>
    
    </div>
    
  
    <div id="navigation">
      <ul>
        <li><a class="active">Főoldal</a></li>
        <li><a href="segitseg.php">Segítség</a></li>
        <li><a href="elerhetosegek.html">Elérhetőségek</a></li>
        <li><a href="profile.php">Profilom</a></li>
       
      </ul>
    </div>
    
    
  </div>
  
  
    
   
    <div id="content">
      
      
   

   <div class="box-container">

   <?php
      $show_products = $conn->prepare("SELECT * FROM `hirdetesek`");
      $show_products->execute();
      if($show_products->rowCount() > 0){
         while($fetch_products = $show_products->fetch(PDO::FETCH_ASSOC)){ 
         
         
   ?>
   <form action="" method="post" class="box">
         <img src=".hirdetes_kepek/<?= $fetch_products['kep1']; ?>" alt="">
         <input type="hidden" name="kep1" value="<?= $fetch_products['kep1']; ?>">
         <img src=".hirdetes_kepek/<?= $fetch_products['kep2']; ?>" alt="">
         <img src=".hirdetes_kepek/<?= $fetch_products['kep3']; ?>" alt="">
         <img src=".hirdetes_kepek/<?= $fetch_products['kep4']; ?>" alt="">
         <img src=".hirdetes_kepek/<?= $fetch_products['kep5']; ?>" alt="">
         <div><?= $fetch_products['allapot']; ?></div>
         <div><?= $fetch_products['marka']; ?></div>
         <input type="hidden" name="marka" value="<?= $fetch_products['marka']; ?>">
         <div><?= $fetch_products['nem']; ?></div>
         <div><?= $fetch_products['sportag']; ?></div>
         <div><?= $fetch_products['szin']; ?></div>
         <div><?= $fetch_products['termektipus']; ?></div>
         <input type="hidden" name="termektipus" value="<?= $fetch_products['termektipus']; ?>">
         <div><?= $fetch_products['leiras']; ?></div>

         <div class="flex">
            <h1><?= $fetch_products['ar']; ?><span>Ft</span></h1>
            <input type="hidden" name="ar" value="<?= $fetch_products['ar']; ?>">
            <button type="submit" name="add_to_cart">Kosárhoz ad</button>
         </div>
      </form>
   <?php
         }
      }else{
         echo '<p class="empty">Nincs még feltöltve hírdetés!</p>';
      }
   ?>

   </div>
   </form>


      
      
    </div>
    
    <div id="sidebar">
      <div class="box search">
        <div class="box-content">
      <form action="#" method="post">
        <label id="kis-cim"">Sportok</label>
          <select id="inSport" class="field">
            <option selected>Válasszon</option>
            <option value="1">Labdarúgás</option>
            <option value="2">Vizes Sportok</option>
            <option value="3">Tenisz</option>
            <option value="4">Sport Bicikli</option>
            <option value="5">Golf</option>
            <option value="6">Kosárlabda</option>
          </select> <br>

          <div class="inline-field">
            <label for="min">Minimum ár</label>
            <input type="number" class="field small-field" name="min" min="0">
            <label for="max">Maximum ár</label>
            <input type="number" class="field small-field" name="max">
          </div>

          <input type="submit" class="search-submit" value="Keresés">
          </form>
          </div>
          </div>
          
          
         
    
  
        
   
     
      <div class="box categories">
        <h2>Termékek <span></span></h2>
        <div class="box-content">
          <ul>
            <li><a href="#">Labdarúgás felszerelés</a></li>
            <li><a href="#">Vizes sportok</a></li>
            <li><a href="#">Tenisz</a></li>
            <li><a href="#">Sport Bicikli</a></li>
            <li><a href="#">Golf</a></li>
            <li class="last"><a href="#">Kosárlabda</a></li>
            
          </ul>
        </div>
      </div>
      
    </div>
   
    <div class="cl">&nbsp;</div>
  </div>
  
  <div class="side-full">
    
    
   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"><a href="Segitseg.html">Segítség</a> <span>|</span> <a href="elérhetőségek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>

<script src="js/script.js"></script>

</body>
</html>
<?php
  ob_end_flush(); 
?>
