<?php

include 'php/db_csat.php';

session_start();

$user_id = $_SESSION['user_id'];

if(!isset($user_id)){
   header('location:auth/login.php');
};

if(isset($_POST['add_product'])){

   $allapot = $_POST['allapot'];
   $allapot = filter_var($allapot, FILTER_SANITIZE_STRING);
   $marka = $_POST['marka'];
   $marka = filter_var($marka, FILTER_SANITIZE_STRING);
   $nem = $_POST['nem'];
   $nem = filter_var($nem, FILTER_SANITIZE_STRING);
   $sportag = $_POST['sportag'];
   $sportag = filter_var($sportag, FILTER_SANITIZE_STRING);
   $szin = $_POST['szin'];
   $szin = filter_var($szin, FILTER_SANITIZE_STRING);
   $termektipus = $_POST['termektipus'];
   $termektipus = filter_var($termektipus, FILTER_SANITIZE_STRING);
   $ar = $_POST['ar'];
   $ar = filter_var($ar, FILTER_SANITIZE_STRING);
   $leiras = $_POST['leiras'];
   $leiras = filter_var($leiras, FILTER_SANITIZE_STRING);

   $kep1 = $_FILES['kep1']['name'];
   $kep1 = filter_var($kep1, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['kep1']['size'];
   $image_tmp_name = $_FILES['kep1']['tmp_name'];
   $image_folder = 'hirdetes_kepek/'.$kep1;
   $kep2 = $_FILES['kep2']['name'];
   $kep2 = filter_var($kep2, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['kep2']['size'];
   $image_tmp_name = $_FILES['kep2']['tmp_name'];
   $image_folder = 'hirdetes_kepek/'.$kep2;
   $kep3 = $_FILES['kep3']['name'];
   $kep3 = filter_var($kep3, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['kep3']['size'];
   $image_tmp_name = $_FILES['kep3']['tmp_name'];
   $image_folder = 'hirdetes_kepek/'.$kep3;
   $kep4 = $_FILES['kep4']['name'];
   $kep4 = filter_var($kep4, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['kep4']['size'];
   $image_tmp_name = $_FILES['kep4']['tmp_name'];
   $image_folder = 'hirdetes_kepek/'.$kep4;
   $kep5 = $_FILES['kep5']['name'];
   $kep5 = filter_var($kep5, FILTER_SANITIZE_STRING);
   $image_size = $_FILES['kep5']['size'];
   $image_tmp_name = $_FILES['kep5']['tmp_name'];
   $image_folder = 'hirdetes_kepek/'.$kep5;

   $select_products = $conn->prepare("SELECT * FROM `hirdetesek` WHERE id = ?");
   $select_products->execute([$id]);

   if($image_size > 2000000){
      $message[] = 'kép mérete túl nagy';
      }else{
         move_uploaded_file($image_tmp_name, $image_folder);

         $insert_product = $conn->prepare("INSERT INTO `hirdetesek`(allapot, marka, nem, sportag, szin, termektipus, ar, leiras, kep1, kep2, kep3, kep4, kep5) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
         $insert_product->execute([$allapot, $marka, $nem, $sportag, $szin, $termektipus, $ar, $leiras, $kep1, $kep2, $kep3, $kep4, $kep5]);

         $message[] = 'új hírdetés hozzáadva!';
      }

   }



if(isset($_GET['delete'])){

   $delete_id = $_GET['delete'];
   $delete_product_image = $conn->prepare("SELECT * FROM `hirdetesek` WHERE id = ?");
   $delete_product_image->execute([$delete_id]);
   $fetch_delete_image = $delete_product_image->fetch(PDO::FETCH_ASSOC);
   unlink('hirdetes_kepek/'.$fetch_delete_image['kep']);
   $delete_product = $conn->prepare("DELETE FROM `hirdetesek` WHERE id = ?");
   $delete_product->execute([$delete_id]);
   $delete_cart = $conn->prepare("DELETE FROM `cart` WHERE pid = ?");
   $delete_cart->execute([$delete_id]);
   header('location:index.php');

}

if(isset($message)){
  foreach($message as $message){
     echo '
     <div class="message">
        <span>'.$message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>
     ';
  }
}

?>
<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Hírdetés feltöltés</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.php">Főoldal</a></li>
        <li><a>Segítség</a></li>
        <li><a href="elerhetosegek.html">Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">
    
<form action="" method="POST" enctype="multipart/form-data">
   <h3>Hírdetés feltöltése</h3>
   <input type="text" required placeholder="Adja meg a termék márkáját" name="marka" maxlength="50" class="box">
   <input type="text" required placeholder="Adja meg a helyes sportágat" name="sportag" maxlength="50" class="box">
   <input type="text" required placeholder="Adja meg a termék színét" name="szin" maxlength="50" class="box">
   <input type="text" required placeholder="Adja meg a termék típusát" name="termektipus" maxlength="50" class="box">
   <input type="number" min="0" max="9999999999" required placeholder="Adja meg a termék árát" name="ar" onkeypress="if(this.value.length == 10) return false;" class="box">
   <textarea name="msg" class="box" required placeholder="Adja meg a termék leírását!" maxlength="500" cols="30" rows="10"></textarea>
   <select name="nem" class="box" required>
      <option value="" disabled selected>Válassza ki a nemet</option>
      <option value="Női">Női</option>
      <option value="Férfi">Férfi</option>
      <option value="Uniszex">Uniszex</option>
      </select>
      <select name="allapot" class="box" required>
      <option value="" disabled selected>Válassza ki a termék állapotát</option>
      <option value="Új">Új</option>
      <option value="Újszerű">Újszerű</option>
      <option value="Használt">Használt</option>
      <option value="Sérült/szakadt">Sérült/szakadt</option>
      </select>
   <input type="file" name="kep1" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
   <input type="file" name="kep2" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
   <input type="file" name="kep3" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
   <input type="file" name="kep4" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
   <input type="file" name="kep5" class="box" accept="image/jpg, image/jpeg, image/png, image/webp">
   <input type="submit" value="Feltöltés" name="add_product" class="btn">
</form>


      </div>
    
    
  
  <div class="side-full">
    

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="index.html">Főoldal</a><span>|</span> <a href="elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>
<script src="js/script.js"></script>

</body>
</html>