<?php

include 'php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['send'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $msg = $_POST['msg'];
   $msg = filter_var($msg, FILTER_SANITIZE_STRING);

   $select_message = $conn->prepare("SELECT * FROM `uzenetek` WHERE name = ? AND email = ? AND number = ? AND message = ?");
   $select_message->execute([$name, $email, $number, $msg]);

       $insert_message = $conn->prepare("INSERT INTO `uzenetek`(user_id, name, email, number, message) VALUES(?,?,?,?,?)");
      $insert_message->execute([$user_id, $name, $email, $number, $msg]);

      $message[] = 'Üzenetét sikeresen elküldte!';

   

}

if(isset($message)){
    foreach($message as $message){
       echo '
       <div class="message">
          <span>'.$message.'</span>
          <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
       </div>
       ';
    }
 }

?>

<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Segítség</a></h1>
    
    <div id="cart"> <a href="bevasarlokocsi.php" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="index.html">Főoldal</a></li>
        <li><a>Segítség</a></li>
        <li><a href="elerhetosegek.html">Elérhetőségek</a></li>
        <li><a href="auth/login.php">Profilom</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
    <div class="cl">&nbsp;</div>
   
    <div id="content">

    <form action="" method="post">
         <h3>Küldjön üzenetet nekünk!</h3>
         <input type="text" name="name" maxlength="50" class="box" placeholder="Írja be a nevét" required>
         <input type="number" name="number" min="0" max="9999999999" class="box" placeholder="Írja be a telefonszámát" required maxlength="20">
         <input type="email" name="email" maxlength="50" class="box" placeholder="Írja be az email címét" required>
         <textarea name="msg" class="box" required placeholder="Mi az üzenete számunkra?" maxlength="500" cols="30" rows="10"></textarea>
         <input type="submit" value="Üzenet elküldése" name="send" class="btn">
      </form>
      </div>
    
    
  
  <div class="side-full">
    

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="index.html">Főoldal</a><span>|</span> <a href="elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>
<script src="js/script.js"></script>

</body>
</html>
