<?php

include '../php/db_csat.php';


session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $name = $_POST['name'];
   $name = filter_var($name, FILTER_SANITIZE_STRING);
   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $number = $_POST['number'];
   $number = filter_var($number, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);
   $cpass = sha1($_POST['cpass']);
   $cpass = filter_var($cpass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `felhasznalo` WHERE email = ? OR number = ?");
   $select_user->execute([$email, $number]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $message[] = 'email vagy telefonszám már létezik!';
   }else{
      if($pass != $cpass){
         $message[] = 'A jelszavak nem egyeznek!';
      }else{
         $insert_user = $conn->prepare("INSERT INTO `felhasznalo`(name, email, number, password) VALUES(?,?,?,?)");
         $insert_user->execute([$name, $email, $number, $cpass]);
         $select_user = $conn->prepare("SELECT * FROM `felhasznalo` WHERE email = ? AND password = ?");
         $select_user->execute([$email, $pass]);
         $row = $select_user->fetch(PDO::FETCH_ASSOC);
         if($select_user->rowCount() > 0){
            $_SESSION['user_id'] = $row['id'];
            header('location:../index.php');
         }
      }
   }

}

if(isset($message)){
  foreach($message as $message){
     echo '
     <div class="message">
        <span>'.$message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>
     ';
  }
}
?>


<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Regisztráció</a></h1>
    
    <div id="cart"> <a href="../bevasarlokocsi.html" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="../index.php">Főoldal</a></li>
        <li><a href="../Segitseg.html" >Segítség</a></li>
        <li><a href="../elerhetosegek.html">Elérhetőségek</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">
 <div id = "reg-form">
<form action="" method="post">
      <h3>Regisztráljon itt</h3>
      <input type="text" name="name" required placeholder="Adja meg a nevét" class="box" maxlength="50">
      <br>
      <input type="email" name="email" required placeholder="Adja meg az email címét" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <br>
      <input type="tel" name="number" required placeholder="Adja meg a telefonszámát" class="box" min="0" max="9999999999" maxlength="20">
      <br>
      <input type="password" name="pass" required placeholder="Adjon meg egy jelszót" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <br>
      <input type="password" name="cpass" required placeholder="Írja be a jelszót újra" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
      <br>
      <input type="submit" value="Regisztráljon" name="submit" class="btn">
      <p>Már van fiókja?<a href="login.php">Lépjen be</a></p>
   </form>
    </div>

    <div class="cl">&nbsp;</div>
    
    <div class="cl">&nbsp;</div>
  </div>
  
  <div class="side-full">

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="../index.php">Főoldal</a> <span>|</span> <a href="../Segitseg.html">Segítség</a> <span>|</span> <a href="../elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>

</body>
</html>