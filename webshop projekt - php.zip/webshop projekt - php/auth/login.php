<?php

include '../php/db_csat.php';

session_start();

if(isset($_SESSION['user_id'])){
   $user_id = $_SESSION['user_id'];
}else{
   $user_id = '';
};

if(isset($_POST['submit'])){

   $email = $_POST['email'];
   $email = filter_var($email, FILTER_SANITIZE_STRING);
   $pass = sha1($_POST['pass']);
   $pass = filter_var($pass, FILTER_SANITIZE_STRING);

   $select_user = $conn->prepare("SELECT * FROM `felhasznalo` WHERE email = ? AND password = ?");
   $select_user->execute([$email, $pass]);
   $row = $select_user->fetch(PDO::FETCH_ASSOC);

   if($select_user->rowCount() > 0){
      $_SESSION['user_id'] = $row['id'];
      header('location:../index.php');
   }else{
      $message[] = 'Helytelen email cím vagy jelszó!';
   }

}

if(isset($message)){
  foreach($message as $message){
     echo '
     <div class="message">
        <span>'.$message.'</span>
        <i class="fas fa-times" onclick="this.parentElement.remove();"></i>
     </div>
     ';
  }
}

?>
<!DOCTYPE html>
<html lang ="hu">
<head>
<title>Használt Sportszer</title>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../css/style.css" type="text/css" media="all" />


</head>
<body>

<div class="shell">
  
  <div id="header">
    <h1 id="logo"><a>Bejelentkezés</a></h1>
    
    <div id="cart"> <a href="../bevasarlokocsi.html" class="cart-link">Bevásárló kocsi</a></div>
      
      
    
    <div id="navigation">
      <ul>
        <li><a href="../index.php">Főoldal</a></li>
        <li><a href="../Segitseg.html" >Segítség</a></li>
        <li><a href="../elerhetosegek.html">Elérhetőségek</a></li>
      </ul>
    </div>
    
  </div>
  
  <div id="main">

  <section class="form-container">

<form action="" method="post">
   <h3>Jelentkezzen be</h3>
   <input type="email" name="email" required placeholder="Írja be az email címét" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
   <br>
   <input type="password" name="pass" required placeholder="Írja be a jelszavát" class="box" maxlength="50" oninput="this.value = this.value.replace(/\s/g, '')">
   <br>
   <input type="submit" value="Bejelentkezés" name="submit" class="btn">
   <br>
   <p>Nincs fiókja? <a href="registration.php">Regisztráljon most</a></p>
</form>

</section>
    <div class="cl">&nbsp;</div>
    
    <div class="cl">&nbsp;</div>
  </div>
  
  <div class="side-full">

   
    <div class="cols">
     
      <div class="col">
        <h3 class="ico ico1">Szállítás</h3>
        <p>Nemzetközi házhoz szállítással segítjük a vásárlóink igényeinek a kielégítését.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico2">Elérhetőségek</h3>
        <p>Bármi féle segítségre van szüksége vagy valami nem megfelelő önnek keressen fel minket emailben vagy akár telefonon. elérhetőségeinket megtalálja az "Elérhetőségek" fül alatt.</p>
        
      </div>
      <div class="col">
        <h3 class="ico ico3">Ajándék</h3>
        <p>Ha egyik szerettét szeretné meglepni egy új foci cipővel abban is tudunk segíteni! Külön kérésre különleges csomagolással is tudunk szolgálni!</p>
        
      </div>
      <div class="col col-last">
        <h3 class="ico ico4">Kosár tartalma</h3>
        <p>A kosárba helyezés nem foglalja le a terméket tehát igyekezzen minél hamarabb megvásárolni!</p>
        
      </div>
      <div class="cl">&nbsp;</div>
    </div>
    
  </div>
  
  <div id="footer">
    <p class="left"> <a href="../index.php">Főoldal</a> <span>|</span> <a href="../Segitseg.html">Segítség</a> <span>|</span> <a href="../elerhetosegek.html">Elérhetőségek</a> </p>
    <p class="right"> A weboldal ami fellendíti a sport karriered! </p>
  </div>
  
</div>

</body>
</html>

















